import javax.swing.*;
import org.jdesktop.swing.calendar.*;
import org.jdesktop.swing.*;

public class JXDatePickerDemo {
    public static void main(String args[]) {
        JFrame frame = new JFrame("Date Picker Demo");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        final JXDatePicker datePicker = new JXDatePicker();
        frame.getContentPane().add(datePicker);
        frame.pack();
        frame.setVisible(true);
    }
}
