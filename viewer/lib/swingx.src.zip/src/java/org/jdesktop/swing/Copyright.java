package org.jdesktop.swing;

public class Copyright {
    public final static String	copyright =
        "Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle, Santa Clara, California 95054, U.S.A. All rights reserved.";
}