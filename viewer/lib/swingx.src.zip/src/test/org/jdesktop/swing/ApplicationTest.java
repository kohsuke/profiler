/*
 * $Id: ApplicationTest.java,v 1.3 2004/09/08 01:37:46 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.swing;

import java.awt.GraphicsEnvironment;

import java.net.URL;

import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JFrame;

import junit.framework.TestCase;

/**
 * Test to ensure that the static methods of the Application
 * class will work.
 */
public class ApplicationTest extends TestCase {

    public void testGetIcon() {
        // Bogus icon
        assertNull(Application.getIcon("images/foo.gif", this));
        assertNotNull(Application.getIcon("/toolbarButtonGraphics/general/Find16.gif", this));
    }

    public void testGetInstance() {
        assertNotNull(Application.getInstance());
        assertNotNull(Application.getInstance(this));
        assertNotSame(Application.getInstance(), Application.getInstance(this));
    }

    public void testGetApp() {
        // Unparented component should not have an app instance.
        JButton button = new JButton("foo");
        assertNull(Application.getApp(button));

        // This rest of this test is not applicable in a headless env.
        if (GraphicsEnvironment.isHeadless()) {
            return;
        }

        // Register a window
        JFrame frame = new JFrame();
        frame.getContentPane().add(button);
        Application app = Application.getInstance(frame);
        app.registerWindow(frame);

        assertNotNull(Application.getApp(button));

        JFrame frame2 = new JFrame();
        JButton button2 = new JButton("foo");
        frame2.getContentPane().add(button2);
        assertNotNull(Application.getApp(button2));
    }

    public void testEnvironment() {
        Application app = Application.getInstance();

        assertTrue(app.isStandAlone());
        assertFalse(app.isRunningApplet());
        assertFalse(app.isRunningInSandbox());
        assertFalse(app.isRunningWebStart());
    }

    /* How can we test and verify this in different contexts?
       public void testShowDocument() {
       Application app = Application.getInstance();

       URL url = Application.class.getResource("resources/test.html");
       assertNotNull(url);
       app.showDocument(url, null);
       }
    */
}
