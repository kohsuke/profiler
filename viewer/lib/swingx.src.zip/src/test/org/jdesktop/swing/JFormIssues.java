/*
 * $Id: JFormIssues.java,v 1.3 2004/12/17 14:40:36 kleopatra Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */
package org.jdesktop.swing;

import java.awt.Dimension;
import java.awt.Insets;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.*;
import javax.swing.JComponent;
import javax.swing.border.CompoundBorder;
import javax.swing.text.JTextComponent;

import org.jdesktop.swing.binding.Binding;
import org.jdesktop.swing.binding.TextBinding;
import org.jdesktop.swing.data.*;
import org.jdesktop.swing.data.DataModel;
import org.jdesktop.swing.data.Validator;
import org.jdesktop.swing.form.*;
import org.jdesktop.swing.form.DefaultFormFactory;
import org.jdesktop.swing.form.JForm;

/**
 * @author Jeanette Winzenburg
 */
public class JFormIssues extends JFormUnitTest {

    /**
     * Issue #128: JForm allows invalid data to be pushed. <p>
     * 
     * assert that form detects invalid DataModel, 
     * invalid by datamodel validator, invalid data set in binding.
     */
    public void testFormInvalidOnInvalidModelBinding() {
        JForm form = assertFormValiditySynchedOnFields(true);
        DataModel personModel = form.getBindings()[0].getDataModel();
        Validator marriedAgeValidator = createMarriedAgeValidator(personModel);
        personModel.addValidator(marriedAgeValidator);

        Binding binding = getBinding(form, "age");
        setSpinnerValue(binding, new Integer(10));

        assertFalse("form must be invalid", form.isFormValid());

    }

    public void testBindingListeningToMetaData() {
        FormFactory.setDefaultFormFactory(new TestFormFactory());
        DataModel personModel = TestDataModelFactory
        	.createFilledPersonModel(true);
        JForm form = createForm(personModel);
        Binding binding = getBinding(form, "firstname");
        JTextComponent textComponent = (JTextComponent) binding.getComponent();
        assertTrue("textField must be editable", textComponent.isEditable());
        MetaData metaData = binding.getDataModel().getMetaData("firstname");
        metaData.setCustomProperty("editable", Boolean.FALSE);
        assertFalse("textField must not be editable", textComponent.isEditable());
    }
    
    public void testValueDependentMetaData() {
        FormFactory.setDefaultFormFactory(new TestFormFactory());
        DataModel personModel = TestDataModelFactory
        	.createFilledPersonModel(true);
        JForm form = createForm(personModel);
        connectEditable(personModel, "married", "firstname");
        // sanity assert
        assertTrue(((Boolean) personModel.getValue("married")).booleanValue());
        Binding binding = getBinding(form, "firstname");
        JTextComponent textComponent = (JTextComponent) binding.getComponent();
        
        assertTrue("textField must be editable", textComponent.isEditable());
//        textComponent.setText("newvalue");
//        personModel.setValue("married", Boolean.FALSE);
        JCheckBox checkBox = (JCheckBox) getBinding(form, "married").getComponent();
        checkBox.setSelected(false);
        assertFalse("textField must not be editable", textComponent.isEditable());
    }
    
    private void connectEditable(final DataModel sourceModel,  final String source,
            final String target) {
          sourceModel.addValueChangeListener(new ValueChangeListener() {

            // not really working: 
            // we don't get ValueChangeEvents during
            // edits... hmmmm
            public void valueChanged(ValueChangeEvent e) {
              if (source.equals(e.getFieldName())) {
                MetaData metaData = sourceModel.getMetaData(target);
                metaData.setCustomProperty("editable",
                    sourceModel.getValue(source));
              }
            }
          });
        }
    
    public class TestFormFactory extends DefaultFormFactory {
        
            public Binding createBinding(DataModel model, String fieldName,
                JComponent component) {
                if (component instanceof JTextComponent) {
                    Binding binding = new TestTextBinding((JTextComponent) component, model, fieldName);
                    int iconPosition = component instanceof JTextArea?
                        SwingConstants.NORTH_EAST : SwingConstants.EAST;
                    BindingBorder bborder = new BindingBorder(binding, iconPosition);
                    Insets insets = bborder.getBorderInsets(component);
                    Dimension prefSize = component.getPreferredSize();
                    prefSize.width += (insets.left + insets.right);
                    component.setPreferredSize(prefSize);
                    component.setBorder(new CompoundBorder(component.getBorder(),bborder));
                    return binding;
                }
            return super.createBinding(model, fieldName, component);
        }
}
    public class TestTextBinding extends TextBinding {

        public TestTextBinding(JTextComponent textComponent, DataModel model, String fieldName) {
            super(textComponent, model, fieldName);
            installMetaDataListener();
        }

        private void installMetaDataListener() {
            metaData.addPropertyChangeListener(new PropertyChangeListener() {

                public void propertyChange(PropertyChangeEvent evt) {
                    if (!"editable".equals(evt.getPropertyName())) return;
                    boolean enabled = ((Boolean) evt.getNewValue()).booleanValue();
                    ((JTextComponent) getComponent()).setEditable(enabled);
                    
                }
                
            });
            
        }

    }
    
}
