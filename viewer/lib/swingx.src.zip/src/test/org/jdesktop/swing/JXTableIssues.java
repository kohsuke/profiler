/*
 * $Id: JXTableIssues.java,v 1.1 2004/12/15 15:12:07 kleopatra Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */
package org.jdesktop.swing;

import java.util.Date;

import javax.swing.Icon;

import junit.framework.TestCase;

import org.jdesktop.swing.data.Link;

/**
 * @author Jeanette Winzenburg
 */
public class JXTableIssues extends TestCase {

    public void testLazyRenderersByClass() {
        JXTable table = new JXTable();
        assertEquals("default Boolean renderer", JXTable.BooleanRenderer.class, table.getDefaultRenderer(Boolean.class).getClass());
        assertEquals("default Number renderer", JXTable.NumberRenderer.class, table.getDefaultRenderer(Number.class).getClass());
        assertEquals("default Double renderer", JXTable.DoubleRenderer.class, table.getDefaultRenderer(Double.class).getClass());
        assertEquals("default Date renderer", JXTable.DateRenderer.class, table.getDefaultRenderer(Date.class).getClass());
        assertEquals("default Link renderer", JXTable.LinkRenderer.class, table.getDefaultRenderer(Link.class).getClass());
        assertEquals("default Icon renderer", JXTable.IconRenderer.class, table.getDefaultRenderer(Icon.class).getClass());
    }

    
}
