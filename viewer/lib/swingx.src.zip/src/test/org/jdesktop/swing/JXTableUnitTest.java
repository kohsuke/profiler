/*
 * $Id: JXTableUnitTest.java,v 1.2 2004/08/07 06:38:30 aim Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.swing;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Point;

import java.lang.reflect.Method;

import java.net.MalformedURLException;
import java.net.URL;

import java.util.Date;

import javax.swing.AbstractButton;
import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JToolBar;

import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;

import org.jdesktop.swing.data.Link;

import org.jdesktop.swing.data.TabularDataModel;
import org.jdesktop.swing.data.TabularDataTextLoader;

import org.jdesktop.swing.JXTable;
import org.jdesktop.swing.LabelProperties;

import org.jdesktop.swing.actions.TargetableAction;

import org.jdesktop.swing.decorator.AlternateRowHighlighter;
import org.jdesktop.swing.decorator.Filter;
import org.jdesktop.swing.decorator.FilterPipeline;
import org.jdesktop.swing.decorator.Highlighter;
import org.jdesktop.swing.decorator.HighlighterPipeline;
import org.jdesktop.swing.decorator.PatternFilter;
import org.jdesktop.swing.decorator.PatternHighlighter;
import org.jdesktop.swing.decorator.ShuttleSorter;

import org.jdesktop.swing.table.ColumnHeaderRenderer;
import org.jdesktop.swing.table.TableColumnExt;

public class JXTableUnitTest extends InteractiveTestCase {

    private DynamicTableModel tableModel = null;

    public JXTableUnitTest() {
        super("JXTable unit test");
    }

    protected void setUp() {
        if (tableModel == null) {
            tableModel = new DynamicTableModel();
        }
    }

    public void testLinkCellType() {
        JXTable table = new JXTable(tableModel);

        assertEquals(Link.class,
                     table.getColumnClass(DynamicTableModel.IDX_COL_LINK));

        TableCellRenderer renderer = table.getCellRenderer(0,
            DynamicTableModel.IDX_COL_LINK);

        // XXX note: this should be a LinkCellRenderer LinkRenderer is not public.
        //	assertEquals(renderer.getClass(),
        //             org.jdesktop.swing.table.TableCellRenderers$LinkRenderer.class);
    }

    public void testDynamicColumns() {
        URL url = JXTableUnitTest.class.getResource("resources/bugdata.txt");
        TabularDataModel data = new TabularDataModel(url);
        JXTable table = new JXTable(data);
        try {
            data.startLoading();
        }
        catch (Exception ex) {
            fail("Exception in data load: " + ex.getMessage());
        }

        while(data.isLoading());

        assertEquals(8, data.getColumnCount());
        assertEquals(8, table.getColumnCount());
    }

    public void interactiveTestTableLoading() {
        URL url = JXTableUnitTest.class.getResource("resources/stringdata.csv");
        System.out.println("url="+url);
        TabularDataModel data = new TabularDataModel(url);
        TabularDataTextLoader loader = (TabularDataTextLoader)data.getLoader();
        loader.setFirstRowHeader(true);
        loader.setColumnDelimiter(",");
        JXTable table = new JXTable(data);
        try {
            data.startLoading();
        }
        catch (Exception ex) {
            fail("Exception in data load: " + ex.getMessage());
        }
        JFrame frame = wrapWithScrollingInFrame(table, "TableLoading Test");
        frame.setVisible(true);  // RG: Changed from deprecated method show();
    }

    public void interactiveTestLinkCell() {
        JXTable table = new JXTable(tableModel);
        JFrame frame = wrapWithScrollingInFrame(table, "TableLinkCell Test");
        frame.setVisible(true);  // RG: Changed from deprecated method show();
    }

    public void interactiveTestTableSizing1() {
        JXTable table = new JXTable();
        table.setAutoCreateColumnsFromModel(false);
        table.setModel(tableModel);

        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

        TableColumnExt columns[] = new TableColumnExt[tableModel.getColumnCount()];
        for (int i = 0; i < columns.length; i++) {
            columns[i] = new TableColumnExt(i);
            table.addColumn(columns[i]);
        }
        columns[0].setPrototypeValue(new Integer(0));
        columns[1].setPrototypeValue("Simple String Value");
        columns[2].setPrototypeValue(new Integer(1000));
        columns[3].setPrototypeValue(Boolean.TRUE);
        columns[4].setPrototypeValue(new Date(100));
        columns[5].setPrototypeValue(new Float(1.5));
        columns[6].setPrototypeValue(new Link("Sun Micro", "_blank",
                                              tableModel.linkURL));
        columns[7].setPrototypeValue(new Integer(3023));
        columns[8].setPrototypeValue("John Doh");
        columns[9].setPrototypeValue("23434 Testcase St");
        columns[10].setPrototypeValue(new Integer(33333));
        columns[11].setPrototypeValue(Boolean.FALSE);

        table.setVisibleRowCount(12);

        JFrame frame = wrapWithScrollingInFrame(table, "TableSizing1 Test");
        frame.setVisible(true);
    }

    public void interactiveTestTableSizing2() {
        JXTable table = new JXTable();
        table.setAutoCreateColumnsFromModel(false);
        table.setModel(tableModel);

        TableColumnExt columns[] = new TableColumnExt[6];
        int viewIndex = 0;
        for (int i = columns.length - 1; i >= 0; i--) {
            columns[viewIndex] = new TableColumnExt(i);
            table.addColumn(columns[viewIndex++]);
        }
        columns[5].setHeaderValue("String Value");
        columns[5].setPrototypeValue("9999");
        columns[4].setHeaderValue("String Value");
        columns[4].setPrototypeValue("Simple String Value");
        columns[3].setHeaderValue("Int Value");
        columns[3].setPrototypeValue(new Integer(1000));
        columns[2].setHeaderValue("Bool");
        columns[2].setPrototypeValue(Boolean.FALSE);
        //columns[2].setSortable(false);
        columns[1].setHeaderValue("Date");
        columns[1].setPrototypeValue(new Date(0));
        //columns[1].setSortable(false);
        columns[0].setHeaderValue("Float");
        columns[0].setPrototypeValue(new Float(5.5));

        table.setRowHeight(24);
        table.setRowMargin(2);
        JFrame frame = wrapWithScrollingInFrame(table, "TableSizing2 Test");
        frame.setVisible(true);
    }

    public void interactiveTestTableAlternateHighlighter1() {
        JXTable table = new JXTable(tableModel);
        table.setRowHeight(22);
        table.setRowMargin(1);

        table.setFilters(new FilterPipeline(new Filter[] {
                                            new ShuttleSorter(0, true) // column 0, ascending
        }));

        table.setHighlighters(new HighlighterPipeline(new Highlighter[] {
            AlternateRowHighlighter.
            linePrinter,
        }));

        JFrame frame = wrapWithScrollingInFrame(table, "TableAlternateRowHighlighter1 Test");
        frame.setVisible(true);
    }

    public void interactiveTestTableAlternateRowHighlighter2() {
        JXTable table = new JXTable(tableModel);
        table.setRowHeight(22);
        table.setRowMargin(1);
        table.setFilters(new FilterPipeline(new Filter[] {
                                            new ShuttleSorter(1, false), // column 1, descending
        }));

        table.setHighlighters(new HighlighterPipeline(new Highlighter[] {
            AlternateRowHighlighter.classicLinePrinter,
        }));

        JFrame frame = wrapWithScrollingInFrame(table, "TableAlternateRowHighlighter2 Test");
        frame.setVisible(true);
    }

    public void interactiveTestTableSorter1() {
        JXTable table = new JXTable(tableModel);
        table.setHighlighters(new HighlighterPipeline(new Highlighter[] {
            AlternateRowHighlighter.notePadBackground,
        }));
        table.setBackground(new Color(0xFF, 0xFF, 0xCC)); // notepad
        table.setGridColor(Color.cyan.darker());
        table.setRowHeight(22);
        table.setRowMargin(1);
        table.setShowHorizontalLines(true);
        table.setFilters(new FilterPipeline(new Filter[] {
                                            new ShuttleSorter(0, true), // column 0, ascending
                                            new ShuttleSorter(1, true), // column 1, ascending
        }));

        JFrame frame = wrapWithScrollingInFrame(table, "TableSorter1 Test");
        frame.setVisible(true);

    }

    public void interactiveTestTableSorter2() {
        JXTable table = new JXTable(tableModel);
        table.setBackground(new Color(0xF5, 0xFF, 0xF5)); // ledger
        table.setGridColor(Color.cyan.darker());
        table.setRowHeight(22);
        table.setRowMargin(1);
        table.setShowHorizontalLines(true);
        table.setFilters(new FilterPipeline(new Filter[] {
                                            new ShuttleSorter(0, true), // column 0, ascending
                                            new ShuttleSorter(1, false), // column 1, descending
        }));
        JFrame frame = wrapWithScrollingInFrame(table, "TableSorter2 Test");
        frame.setVisible(true);
    }

    public void interactiveTestTableSorter3() {
        JXTable table = new JXTable(tableModel);
        table.setHighlighters(new HighlighterPipeline(new Highlighter[] {
            new Highlighter(Color.orange, null),
        }));
        table.setFilters(new FilterPipeline(new Filter[] {
                                            new ShuttleSorter(1, true), // column 1, ascending
                                            new ShuttleSorter(0, false), // column 0, descending
        }));
        JFrame frame = wrapWithScrollingInFrame(table, "TableSorter3 Test");
        frame.setVisible(true);
    }

    public void interactiveTestTablePatternFilter1() {
        JXTable table = new JXTable(tableModel);
        table.setIntercellSpacing(new Dimension(1, 1));
        table.setShowGrid(true);
        table.setFilters(new FilterPipeline(new Filter[] {
                                            new PatternFilter("A.*", 0, 1)
        }));
        JFrame frame = wrapWithScrollingInFrame(table, "TablePatternFilter1 Test");
        frame.setVisible(true);
    }

    public void interactiveTestTablePatternFilter2() {
        JXTable table = new JXTable(tableModel);
        table.setIntercellSpacing(new Dimension(2, 2));
        table.setShowGrid(true);
        table.setFilters(new FilterPipeline(new Filter[] {
                                            new PatternFilter("S.*", 0, 1),
                                            new ShuttleSorter(0, false), // column 0, descending
        }));
        JFrame frame = wrapWithScrollingInFrame(table, "TablePatternFilter2 Test");
        frame.setVisible(true);
    }

    public void interactiveTestTablePatternFilter3() {
        JXTable table = new JXTable(tableModel);
        table.setShowGrid(true);
        table.setFilters(new FilterPipeline(new Filter[] {
                                            new PatternFilter("S.*", 0, 1),
                                            new ShuttleSorter(1, false), // column 1, descending
                                            new ShuttleSorter(0, false), // column 0, descending
        }));
        JFrame frame = wrapWithScrollingInFrame(table, "TablePatternFilter3 Test");
        frame.setVisible(true);
    }

    public void interactiveTestTablePatternFilter4() {
        JXTable table = new JXTable(tableModel);
        table.setIntercellSpacing(new Dimension(3, 3));
        table.setShowGrid(true);
        table.setFilters(new FilterPipeline(new Filter[] {
                                            new PatternFilter("A.*", 0, 1),
                                            new ShuttleSorter(0, false), // column 0, descending
        }));
        JFrame frame = wrapWithScrollingInFrame(table, "TablePatternFilter4 Test");
        frame.setVisible(true);
    }

    public void interactiveTestTablePatternFilter5() {
        // **** IMPORTANT TEST CASE for interaction between ****
        // **** PatternFilter and PatternHighlighter!!! ****
        JXTable table = new JXTable(tableModel);
        table.setFilters(new FilterPipeline(new Filter[] {
                                            new PatternFilter("S.*", 0, 1),
                                            new ShuttleSorter(0, false), // column 0, descending
                                            new ShuttleSorter(1, true), // column 1, ascending
                                            new ShuttleSorter(3, false), // column 3, descending
        }));
        table.setHighlighters(new HighlighterPipeline(new Highlighter[] {
            new PatternHighlighter(null, Color.red, "S.*", 0, 1),
        }));
        JFrame frame = wrapWithScrollingInFrame(table, "TablePatternFilter5 Test");
        frame.setVisible(true);
    }

    public void interactiveTestTableViewProperties() {
        JXTable table = new JXTable(tableModel);
        table.setIntercellSpacing(new Dimension(15, 15));
        table.setRowHeight(48);
        JFrame frame = wrapWithScrollingInFrame(table, "TableViewProperties Test");
        frame.setVisible(true);
    }

    public void interactiveTestTablePatternHighlighter() {
        JXTable table = new JXTable(tableModel);
        table.setIntercellSpacing(new Dimension(15, 15));
        table.setRowHeight(48);
        table.setRowHeight(0, 96);
        table.setShowGrid(true);
        table.setHighlighters(new HighlighterPipeline(new Highlighter[] {
            new PatternHighlighter(null, Color.red, "A.*", 0, 1),
        }));
        JFrame frame = wrapWithScrollingInFrame(table, "TablePatternHighlighter Test");
        frame.setVisible(true);
    }

    public void interactiveTestTableColumnProperties() {
        JXTable table = new JXTable();
        table.setModel(tableModel);

        table.getTableHeader().setBackground(Color.green);
        table.getTableHeader().setForeground(Color.magenta);
        table.getTableHeader().setFont(new Font("Serif", Font.PLAIN, 10));

        ColumnHeaderRenderer headerRenderer = new ColumnHeaderRenderer();
        headerRenderer.setHorizontalAlignment(JLabel.CENTER);
        headerRenderer.setBackground(Color.blue);
        headerRenderer.setForeground(Color.yellow);
        headerRenderer.setIcon(new Icon() {
            public int getIconWidth() {
                return 12;
            }

            public int getIconHeight() {
                return 12;
            }

            public void paintIcon(Component c, Graphics g, int x, int y) {
                g.setColor(Color.red);
                g.fillOval(0, 0, 10, 10);
            }
        });
        headerRenderer.setIconTextGap(20);
        headerRenderer.setFont(new Font("Serif", Font.BOLD, 18));

        for (int i = 0; i < table.getColumnCount(); i++) {
            TableColumnExt column = table.getColumnExt(i);
            if (i % 3 > 0) {
                column.setHeaderRenderer(headerRenderer);
            }
            if (i % 2 > 0) {
                TableCellRenderer cellRenderer =
                    table.getNewDefaultRenderer(table.getColumnClass(i));
                if (cellRenderer instanceof JLabel || cellRenderer instanceof AbstractButton) {
                    JLabel labelCellRenderer = (JLabel)cellRenderer;
                    labelCellRenderer.setBackground(Color.gray);
                    labelCellRenderer.setForeground(Color.red);
                    labelCellRenderer.setHorizontalAlignment(JLabel.CENTER);
                    column.setCellRenderer(cellRenderer);
                }
            }
        }

        JFrame frame = wrapWithScrollingInFrame(table, "TableColumnProperties Test");
        frame.setVisible(true);
    }

    public static class DynamicTableModel extends AbstractTableModel {
        private Object columnSamples[];
        private Object columnSamples2[];
        public URL linkURL;

        public static final int IDX_COL_LINK = 6;

        public DynamicTableModel() {
            try {
                linkURL = new URL("http://www.sun.com");
            }
            catch (MalformedURLException ex) {
                throw new RuntimeException(ex);
            }

            columnSamples = new Object[12];
            columnSamples[0] = new Integer(0);
            columnSamples[1] = "Simple String Value";
            columnSamples[2] = new Integer(1000);
            columnSamples[3] = Boolean.TRUE;
            columnSamples[4] = new Date(100);
            columnSamples[5] = new Float(1.5);
            columnSamples[IDX_COL_LINK] = new Link("Sun Micro", "_blank", linkURL);
            columnSamples[7] = new Integer(3023);
            columnSamples[8] = "John Doh";
            columnSamples[9] = "23434 Testcase St";
            columnSamples[10] = new Integer(33333);
            columnSamples[11] = Boolean.FALSE;

            columnSamples2 = new Object[12];
            columnSamples2[0] = new Integer(0);
            columnSamples2[1] = "Another String Value";
            columnSamples2[2] = new Integer(999);
            columnSamples2[3] = Boolean.FALSE;
            columnSamples2[4] = new Date(333);
            columnSamples2[5] = new Float(22.22);
            columnSamples2[IDX_COL_LINK] = new Link("Sun Web", "new_frame", linkURL);
            columnSamples[7] = new Integer(5503);
            columnSamples[8] = "Jane Smith";
            columnSamples[9] = "2343 Table Blvd.";
            columnSamples[10] = new Integer(2);
            columnSamples[11] = Boolean.TRUE;

        }

        public DynamicTableModel(Object columnSamples[]) {
            this.columnSamples = columnSamples;
        }

        public Class getColumnClass(int column) {
            return columnSamples[column].getClass();
        }

        public int getRowCount() {
            return 1000;
        }

        public int getColumnCount() {
            return columnSamples.length;
        }

        public Object getValueAt(int row, int column) {
            Object value;
            if (row % 3 == 0) {
                value = columnSamples[column];
            }
            else {
                value = columnSamples2[column];
            }
            return column == 0 ? new Integer(row >> 3) :
                column == 3 ? new Boolean(row % 2 == 0) : value;
        }

        public boolean isCellEditable(int row, int column) {
            return (column == 1);
        }

        public void setValueAt(Object aValue, int row, int column) {
            if (column == 1) {
                if (row % 3 == 0) {
                    columnSamples[column] = aValue;
                }
                else {
                    columnSamples2[column] = aValue;
                }
            }
            this.fireTableDataChanged();
        }
    }

    public static void main(String args[]) {
        JXTableUnitTest test = new JXTableUnitTest();
        test.setUp();
        try {
            test.runInteractiveTests();
        } catch (Exception e) {
            System.err.println("exception when executing interactive tests:");
            e.printStackTrace();
        }
    }
}
