/*
 * $Id: JXTreeTableUnitTest.java,v 1.1 2004/07/31 00:03:27 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.swing;

import java.util.regex.Pattern;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Point;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JScrollPane;

import org.jdesktop.swing.decorator.AlternateRowHighlighter;
import org.jdesktop.swing.decorator.HierarchicalColumnHighlighter;
import org.jdesktop.swing.decorator.Highlighter;
import org.jdesktop.swing.decorator.HighlighterPipeline;
import org.jdesktop.swing.JXTreeTable;
import org.jdesktop.swing.decorator.PatternHighlighter;
import org.jdesktop.swing.treetable.FileSystemModel;
import org.jdesktop.swing.treetable.TreeTableModel;

public class JXTreeTableUnitTest extends junit.framework.TestCase {

    public JXTreeTableUnitTest() {
	super("JXTreeTable Unit Test");
    }

    public void testDummy() {
	// XXX placeholder test. replace with a real unit test
    }

    public static void main(String[] args) {
	try {
	    //	UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
	}
	catch (Exception ex) {

	}

	final TestCase[] testCases = createTestCases();
	if (testCases.length > 0) {
	    // Automatically exit after last window is closed.
	    testCases[testCases.length - 1].frame.setDefaultCloseOperation(
									   JFrame.EXIT_ON_CLOSE);

	    Point location = testCases[0].frame.getLocation();

            for (int i = testCases.length - 1; i >= 0; i--) {
                location.translate(30, 30); // stagger frames
                testCases[i].frame.setTitle("JXTreeTable Unit Test " + (i +
								       1));
                testCases[i].frame.setLocation(location);
                testCases[i].frame.setVisible(true);
            }
	}
    }

    /**
     * For unit testing only
     * @return
     */
    private static TestCase[] createTestCases() {

	final TreeTableModel treeTableModel = new FileSystemModel();    // shared

        final TestCase[] testCases = new TestCase[] {
            new TestCase(treeTableModel) {
                public JComponent define() {
                    JXTreeTable treeTable = new JXTreeTable(model);
                    treeTable.setRowHeight(22);
                    treeTable.setRowMargin(1);
                    treeTable.setHighlighters(new HighlighterPipeline(new Highlighter[] {
                        AlternateRowHighlighter.quickSilver,
                        new HierarchicalColumnHighlighter(),
                        new PatternHighlighter(null, Color.red, "s.*",
                                               Pattern.CASE_INSENSITIVE, 0, -1),
                        }));
                    return treeTable;
                }
            },

            new TestCase(treeTableModel) {
                public JComponent define() {
                    JXTreeTable treeTable = new JXTreeTable(model);
                    treeTable.setRowHeight(22);
                    treeTable.setRowMargin(1);
                    treeTable.setHighlighters(new HighlighterPipeline(new Highlighter[] {
                        AlternateRowHighlighter.linePrinter,
                        new HierarchicalColumnHighlighter(),
                        }));
                    return treeTable;
                }
            },

            new TestCase(treeTableModel) {
                public JComponent define() {
                    JXTreeTable treeTable = new JXTreeTable(model);
                    treeTable.setHighlighters(new HighlighterPipeline(new Highlighter[] {
                        AlternateRowHighlighter.classicLinePrinter,
                        }));
                    treeTable.setRowHeight(22);
		    		treeTable.setRowMargin(1);
                    return treeTable;
                }
            },

            new TestCase(treeTableModel) {
                public JComponent define() {
                    JXTreeTable treeTable = new JXTreeTable(model);
                    treeTable.setHighlighters(new HighlighterPipeline(new Highlighter[] {
                        AlternateRowHighlighter.notePadBackground,
                        new HierarchicalColumnHighlighter(),
                        }));
                    treeTable.setBackground(new Color(0xFF, 0xFF, 0xCC));    // notepad
                    treeTable.setGridColor(Color.cyan.darker());
                    treeTable.setRowHeight(22);
                    treeTable.setRowMargin(1);
                    treeTable.setShowHorizontalLines(true);
                    return treeTable;
                }
            },

            new TestCase(treeTableModel) {
                public JComponent define() {
                    JXTreeTable treeTable = new JXTreeTable(model);
                    treeTable.setBackground(new Color(0xF5, 0xFF, 0xF5));    // ledger
                    treeTable.setGridColor(Color.cyan.darker());
                    treeTable.setRowHeight(22);
		    		treeTable.setRowMargin(1);
                    treeTable.setShowHorizontalLines(true);
                    return treeTable;
                }
            },

            new TestCase(treeTableModel) {
                public JComponent define() {
                    JXTreeTable treeTable = new JXTreeTable(model);
                    treeTable.setHighlighters(new HighlighterPipeline(new Highlighter[] {
                        new HierarchicalColumnHighlighter(),
                        }));
                    return treeTable;
                }
            },

            new TestCase(treeTableModel) {
                public JComponent define() {
                    JXTreeTable treeTable = new JXTreeTable(model);
                    treeTable.setShowGrid(true);
                    return treeTable;
                }
            },

            new TestCase(treeTableModel) {
                public JComponent define() {
                    JXTreeTable treeTable = new JXTreeTable(model);
                    treeTable.setIntercellSpacing(new Dimension(1, 1));
                    treeTable.setShowGrid(true);
                    return treeTable;
                }
            },

            new TestCase(treeTableModel) {
                public JComponent define() {
                    JXTreeTable treeTable = new JXTreeTable(model);
                    treeTable.setIntercellSpacing(new Dimension(2, 2));
                    treeTable.setShowGrid(true);
                    return treeTable;
                }
            },

            new TestCase(treeTableModel) {
                public JComponent define() {
                    JXTreeTable treeTable = new JXTreeTable(model);
                    treeTable.setIntercellSpacing(new Dimension(3, 3));
                    treeTable.setShowGrid(true);
                    return treeTable;
                }
            },

            new TestCase(treeTableModel) {
                public JComponent define() {
                    JXTreeTable treeTable = new JXTreeTable(model);
                    treeTable.setHighlighters(new HighlighterPipeline(new Highlighter[] {
                        new Highlighter(Color.orange, null),
                        }));
                    treeTable.setIntercellSpacing(new Dimension(15, 15));
                    treeTable.setRowHeight(48);
                    return treeTable;
                }
            },

            new TestCase(treeTableModel) {
                public JComponent define() {
                    JXTreeTable treeTable = new JXTreeTable(model);
                    treeTable.setIntercellSpacing(new Dimension(15, 15));
                    treeTable.setRowHeight(48);
                    //treeTable.setRowHeight(0, 96);
                    treeTable.setShowGrid(true);
                    treeTable.setHighlighters(new HighlighterPipeline(new Highlighter[] {
                        new Highlighter(Color.orange, null),
                        new HierarchicalColumnHighlighter(),
                        new PatternHighlighter(null, Color.red, ".*TreeTable.*", 0, 0),
                        }));
                    return treeTable;
                }
            },
        };
        return testCases;
    }

    private static abstract class TestCase {

	public TestCase(TreeTableModel model) {
	    this.model = model;
	    this.frame = wrap(define());
	}

	public abstract JComponent define();

	public JFrame wrap(JComponent component) {
            final JFrame frame = new JFrame();
            final JScrollPane scroller = new JScrollPane(component);
            scroller.setPreferredSize(new Dimension(600, 304));
            frame.getContentPane().add(scroller);
            frame.pack();
            frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            return frame;
	}

	public final TreeTableModel model;
	public final JFrame frame;
    }
}
