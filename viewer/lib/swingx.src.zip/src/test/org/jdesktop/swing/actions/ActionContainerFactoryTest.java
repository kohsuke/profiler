/*
 * $Id: ActionContainerFactoryTest.java,v 1.1 2004/09/17 23:24:58 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.swing.actions;

import java.awt.Component;

import javax.swing.*;

import junit.framework.TestCase;

import org.jdesktop.swing.Application;

/**
 * Test the action container factory - which is a factory class which creates
 * UI components from actions.
 */
public class ActionContainerFactoryTest extends TestCase {

    private ActionManager manager;

    protected void setUp() {
        manager = new ActionManager();
        ActionManager.setInstance(manager);

        // regular command action
        action("new-command", "New", "N", "Create a new document",
               "/toolbarButtonGraphics/general/New16.gif",
               "/toolbarButtonGraphics/general/New24.gif", "control N", false);

        // toggle action
        action("font-bold", "Bold", "B", "Bold current selection",
               "/toolbarButtonGraphics/text/Bold16.gif",
               "/toolbarButtonGraphics/text/Bold24.gif", "control B", true);
    }

    protected void tearDown() {
        manager = null;
        ActionManager.setInstance(null);
    }

    /**
     * Sanity check for the integrity of the data.
     */
    public void testData() {
        AbstractActionExt action = (AbstractActionExt)manager.getAction("new-command");
        assertNotNull(action);

        Icon smicon = action.getSmallIcon();
        Icon lgicon = action.getLargeIcon();
        assertNotNull(smicon);
        assertNotNull(lgicon);

        assertNotSame("Error: both icons are the same", smicon, lgicon);

        assertTrue(smicon.toString().endsWith("16.gif"));
        assertTrue(lgicon.toString().endsWith("24.gif"));
    }

    public void testCreateButton() {
        AbstractButton button;

        button = manager.getFactory().createButton(manager.getAction("new-command"));

        assertNotNull(button);
        assertTrue(button instanceof JButton);
        assertEquals(button.getMnemonic(), 'N');

        button = manager.getFactory().createButton(manager.getAction("font-bold"));
        assertNotNull(button);
        assertTrue(button instanceof JToggleButton);
    }

    public void testCreateToolbar() {
        JToolBar toolbar;

        toolbar = manager.getFactory().createToolBar(new Object[] { "new-command",
                                                                    null,
                                                                    "font-bold" });
        assertNotNull(toolbar);
        assertTrue(toolbar.getComponentCount() == 3);

        Component comp = toolbar.getComponent(0);
        assertNotNull(comp);
        assertTrue(comp instanceof JButton);

        comp = toolbar.getComponent(1);
        assertNotNull(comp);
        assertTrue(comp instanceof JSeparator);

        comp = toolbar.getComponent(2);
        assertNotNull(comp);
        assertTrue(comp instanceof JToggleButton);
    }

    /**
     * Convenience method to create actions with all the attributes. A factory
     * method for other factory methods.
     */
    private AbstractActionExt action(String id, String name, String mnemonic, String desc,
                          String smicon, String lgicon, String accel, boolean toggle) {
        AbstractActionExt action;
        action = ActionFactory.createTargetableAction(id, name, mnemonic, toggle);

        ActionFactory.decorateAction(action, desc, desc,
                                     Application.getIcon(smicon, this),
                                     Application.getIcon(lgicon, this),
                                     KeyStroke.getKeyStroke(accel));

        return (AbstractActionExt)manager.addAction(action);
    }

}
