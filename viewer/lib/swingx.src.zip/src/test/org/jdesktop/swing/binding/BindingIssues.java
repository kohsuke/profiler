/*
 * $Id: BindingIssues.java,v 1.3 2004/12/17 14:40:36 kleopatra Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.swing.binding;

import javax.swing.JCheckBox;
import javax.swing.text.JTextComponent;

import org.jdesktop.swing.data.DataModel;
import org.jdesktop.swing.data.AbstractDataModelTst;
import org.jdesktop.swing.data.DefaultDataModel;
import org.jdesktop.swing.data.MetaData;
import org.jdesktop.swing.data.TestDataModelFactory;
import org.jdesktop.swing.form.JForm;
import org.jdesktop.swing.util.PropertyChangeReport;

import junit.framework.TestCase;

/**
 * Open binding issues exposed as TestCase. <p>
 * 
 * NOTE: this test is expected to fail. Will be 
 * integrated into BindingUnitTest on resolution.
 * 
 * @author Jeanette Winzenburg
 */
public class BindingIssues extends TestCase {

    private PropertyChangeReport tracker;
    private DefaultDataModel personModel;
    private JForm form;

    
    /** 
     * Issue #115 - BooleanBinding cannot cope with boolean.class. <p>
     * Don't allow primitiv type? DataModel can handle Object only
     * anyway...
     *
     */
    public void testBooleanBindingIsValid() {
        DefaultDataModel model = new DefaultDataModel();
        MetaData booleanMetaData = new MetaData("married", boolean.class);
        model.addField(booleanMetaData);
        JCheckBox checkbox = new JCheckBox(booleanMetaData.getLabel());
        BooleanBinding binding = new BooleanBinding(checkbox, model,
                                   "married");
        binding.pull();
        assertTrue("boolean binding must always be valid ", binding.isValid());
        
      }
    
//  -------------------- modify binding and events
    
    /** 
     * test binding firing modified in simple form.
     *
     */
    public void testSimpleBindingFiresModified() {
      assertFiredModified(form, null, "lastname");
    }

    /** 
     * Issue: #??
     * 
     * test FormBinding firing modified if contained binding 
     * is modified.
     *
     */
    public void testFormBindingFiresModified() {
      Binding formBinding = getBinding(form, "address");
      assertTrue(formBinding instanceof FormBinding);
      assertFiredModified(form, "address", "city");
    }

    private void assertFiredModified(JForm form, String subformFieldname,
        String fieldname) {
      Binding binding = getBinding(form, subformFieldname, fieldname);
      ((JTextComponent) binding.getComponent()).setText("somevalue");
      assertEquals("binding must have fired modified", 1, 
                 tracker.getEventCount("modified"));
    }

//----------------------- helpers installing/accessing bindings
    
    /** returns binding with given fieldName.
     *  if modelFieldName != null returns binding in nested 
     * form with modelFieldName.
     * 
     * @param form
     * @param modelFieldname
     * @param fieldname
     * @return
     */
    private Binding getBinding(JForm form, String modelFieldname,
        String fieldname) {
      if (modelFieldname != null) {
        Binding formBinding = getBinding(form, modelFieldname);
        form = (JForm) formBinding.getComponent();
      }
      return getBinding(form, fieldname);
    }

    /** returns direct binding with given fieldname.
     * 
     * @param form
     * @param fieldname
     * @return
     */
    private Binding getBinding(JForm form, String fieldname) {
      Binding[] bindings = form.getBindings();
      for (int i = 0; i < bindings.length; i++) {
        if (fieldname.equals(bindings[i].getFieldName())) {
          return bindings[i];
        }
      }
      return null;
    }

    /** create form, bind model and install tracker 
     * on all direct bindings.
     * 
     * @param personModel
     * @return
     */
    private JForm createForm(DataModel personModel) {
      JForm form = new JForm();
      try {
        installTracker(form.bind(personModel));
        form.pull();
      } catch (BindException e) {

        // TODO Auto-generated catch block
        e.printStackTrace();
      }
      return form;
    }

    /** registers tracker with all all bindings.
     * 
     * @param bindings
     */
    private void installTracker(Binding[] bindings) {
      for (int i = 0; i < bindings.length; i++) {
        bindings[i].addPropertyChangeListener(tracker);
      }
    }

//----------- super
    protected void setUp()
      throws Exception {
      super.setUp();
      tracker = new PropertyChangeReport();
      personModel = TestDataModelFactory.createNestedPersonModel();
      form = createForm(personModel);
    }

}
