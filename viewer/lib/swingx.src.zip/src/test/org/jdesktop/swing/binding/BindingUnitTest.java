/*
 * $Id: BindingUnitTest.java,v 1.8 2004/12/17 14:40:36 kleopatra Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.swing.binding;

import javax.swing.*;

import junit.framework.TestCase;

import org.jdesktop.swing.data.*;
import org.jdesktop.swing.util.TestSupport;

/**
 * JUnit test class for binding classes.
 * 
 * @author Amy Fowler
 * @author Jeanette Winzenburg
 */
public class BindingUnitTest extends TestCase {

    //--------------------------- testing reset after change

    /** 
     * Issue #78: 
     * test TextBinding modified state after pull/change/pull.
     * <p>
     *
     */
    public void testTextBindingAfterChangeAndPull() {
        DataModel personModel = TestDataModelFactory.createNestedPersonModel();
        JTextField textfield = new JTextField("somevalue");
        TextBinding binding = new TextBinding(textfield, personModel,
                "comments");
        // initial pull
        assertUnmodifiedAfterPull(binding);
        // modify
        textfield.setText("someothervalue");
        assertTrue(binding.isModified());

        // resetting pull
        assertUnmodifiedAfterPull(binding);
    }

    private void assertUnmodifiedAfterPull(Binding binding) {
        assertTrue(binding.pull());
        assertFalse("Binding must be unmodified after pull", binding.isModified());
    }

    /** 
     * Issue #115 - BooleanBinding cannot cope with boolean.class. <p>
     * Don't allow primitiv type? DataModel can handle Object only
     * anyway..<p>
     * 
     * NOTE (JW): this issue is not solved - moved to BindingIssues.java
     * to  not interfere with default build.
     *
     */
    public void testBooleanBindingIsValid() {
//        DefaultDataModel model = new DefaultDataModel();
//        MetaData booleanMetaData = new MetaData("married", boolean.class);
//        model.addField(booleanMetaData);
//        JCheckBox checkbox = new JCheckBox(booleanMetaData.getLabel());
//        BooleanBinding binding = new BooleanBinding(checkbox, model,
//                                   "married");
//        binding.pull();
//        assertTrue("boolean binding must always be valid ", binding.isValid());
        
      }
    
    public void testBooleanBinding() {
        DataModel personModel = TestDataModelFactory.createPersonModel();
        MetaData metaData = personModel.getMetaData("married");
        JCheckBox checkbox = new JCheckBox(metaData.getLabel());
        BooleanBinding binding = new BooleanBinding(checkbox, personModel,
                "married");

        assertTrue(binding.pull());
        assertFalse(binding.isModified());
        assertTrue(binding.isValid()); // not required

        checkbox.setSelected(true);

        assertTrue(binding.isModified());
        assertTrue(binding.isValid());
        assertTrue(binding.push());
        assertFalse(binding.isModified());
        assertTrue(binding.isValid());

        assertEquals(Boolean.TRUE, personModel.getValue("married"));
    }

    /**
     * Issue #84: ComboBoxBinding must guarantee to select
     * items not contained in the listmodel.
     *
     */
    public void testComboBoxBindingAllowsNonContainedSelection() {
        EnumeratedMetaData enumMeta = new EnumeratedMetaData("status", String.class, "Status");
        enumMeta.setEnumeration(TestDataModelFactory.statusTypes);
        DefaultDataModel model = new DefaultDataModel();
        model.addField(enumMeta);
        JComboBox comboBox = new JComboBox(enumMeta.getEnumeration());
        ComboBoxBinding binding = new ComboBoxBinding(comboBox, model, "status");
        binding.pull();
        assertEquals("initial value must be null ", null, comboBox.getSelectedItem());
        model.setValue("status", "unknown");
        assertEquals("comboBox must select uncontained value", 
                model.getValue("status"), comboBox.getSelectedItem());
    }
    
    public void testComboBoxBinding() {
        DataModel personModel = TestDataModelFactory.createNestedPersonModel();
        DataModel addressModel = (DataModel) personModel.getValue("address");
        EnumeratedMetaData metaData = (EnumeratedMetaData) addressModel
                .getMetaData("state");
        JComboBox combobox = new JComboBox(metaData.getEnumeration());
        ComboBoxBinding binding = new ComboBoxBinding(combobox, addressModel,
                "state");

        assertTrue(binding.pull());
        assertFalse(binding.isModified());
        assertFalse(binding.isValid()); // required

        combobox.setSelectedIndex(4); // "California"

        assertTrue(binding.isModified());
        assertTrue(binding.isValid());
        assertTrue(binding.push());
        assertFalse(binding.isModified());
        assertTrue(binding.isValid());

        assertEquals("California", addressModel.getValue("state"));
    }

    public void testLabelBinding() {
        DataModel personModel = TestDataModelFactory.createPersonModel();
        MetaData metaData = personModel.getMetaData("customerid");
        JLabel label = new JLabel(metaData.getLabel());
        LabelBinding binding = new LabelBinding(label, personModel,
                "customerid");

        assertTrue(binding.pull());
        assertFalse(binding.isModified());
        assertTrue(binding.isValid()); // not required
    }

    public void testTextBinding() {
        DataModel personModel = TestDataModelFactory.createNestedPersonModel();
        StringMetaData metaData = (StringMetaData) personModel
                .getMetaData("lastname");
        JTextField textfield = new JTextField(metaData.getDisplayWidth());
        TextBinding binding = new TextBinding(textfield, personModel,
                "lastname");

        assertTrue(binding.pull());
        assertFalse(binding.isModified());
        assertFalse(binding.isValid()); // required

        textfield.setText("Moore");

        assertTrue(binding.isModified());
        assertTrue(binding.isValid());
        assertTrue(binding.push());
        assertFalse(binding.isModified());
        assertTrue(binding.isValid());

        assertEquals("Moore", personModel.getValue("lastname"));
    }

    public void testPropertyChangeSupport() {
        DataModel personModel = TestDataModelFactory.createPersonModel();
        StringMetaData metaData = (StringMetaData) personModel
                .getMetaData("lastname");
        JTextField textfield = new JTextField(metaData.getDisplayWidth());
        TextBinding binding = new TextBinding(textfield, personModel,
                "lastname");

        TestSupport.PropertyChangeTracker tracker = new TestSupport.PropertyChangeTracker();

        // test addPropertyChangeListener
        binding.addPropertyChangeListener(tracker);
        assertEquals(1, binding.getPropertyChangeListeners().length);

        assertFalse(tracker.hasPropertyChangeEvents());

        // test that changing UI value will cause "modified" PCE
        textfield.setText("Davidson");
        assertTrue(tracker.gotPropertyChangeEvent("modified"));
        Boolean newValue = (Boolean) tracker.getNewPropertyValue("modified");
        assertTrue(newValue.booleanValue());
        tracker.clear();

        // test that pushing value to model will cause "validState" and
        // "modified" PCEs
        binding.push();
        assertTrue(tracker.gotPropertyChangeEvent("validState"));
        Integer stateValue = (Integer) tracker
                .getNewPropertyValue("validState");
        assertEquals(Binding.VALID, stateValue.intValue());
        assertTrue(tracker.gotPropertyChangeEvent("modified"));
        newValue = (Boolean) tracker.getNewPropertyValue("modified");
        assertFalse(newValue.booleanValue());
        tracker.clear();

        // test that setting to invalid value will cause "validState" PCE
        textfield.setText("");
        assertFalse(binding.isValid());
        assertTrue(tracker.gotPropertyChangeEvent("validState"));
        stateValue = (Integer) tracker.getNewPropertyValue("validState");
        assertEquals(Binding.INVALID, stateValue.intValue());

    }

    public static void main(String args[]) {
        BindingUnitTest test = new BindingUnitTest();

        test.testBooleanBinding();
        test.testComboBoxBinding();
        test.testLabelBinding();
        test.testTextBinding();
        test.testPropertyChangeSupport();
    }

}