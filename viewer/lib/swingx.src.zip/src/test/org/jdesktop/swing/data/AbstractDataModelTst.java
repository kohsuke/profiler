/*
 * $Id: AbstractDataModelTst.java,v 1.1 2004/12/17 14:40:35 kleopatra Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.swing.data;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Logger;

import org.jdesktop.swing.util.PropertyChangeReport;
import org.jdesktop.swing.util.ValueChangeReport;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;


/**
 * JUnit test class for data model interface and implementing classes.
 * 
 * @author Jeanette Winzenburg
 */
public abstract class AbstractDataModelTst extends TestCase {
    protected static final String EXISTING_FIELDNAME = "existing";
    protected static final String NON_EXISTING_FIELDNAME = "non_existing";
    protected static final String VALUE = "somevalue";

    protected MetaData metaData;
    protected PropertyChangeReport propertyReport;
    protected ValueChangeReport valueReport;


    /** 
     * To be decided: what should happen if code tries to
     * access unknown fields?
     * 
     */
    public void testModelInstantiation() {
        DataModel model = createEmptyDataModel(new MetaData[] { metaData }, 1 );
        if (supportsEmptySelection()) {
            model.setRecordIndex(0);
        }
//      try {
//        model.getValue("non_existing");
//        fail("model must throw on non_existing fieldName " );
//      } catch (IllegalArgumentException ex){
//        // nothing registered
//      }
//      try {
//        model.setValue("non_existing", "dummy");
//        fail("model must throw on non_existing fieldName " );
//      } catch (IllegalArgumentException ex){
//        // nothing registered
//      }

    }

    /**
     * test setting value and notification.
     *
     */
    public void testNotificationDataModelSetValue() {
        DataModel model = createEmptyDataModel(new MetaData[] { metaData }, 1 );
        if (supportsEmptySelection()) {
            model.setRecordIndex(0);
        }
        model.addValueChangeListener(valueReport);
        model.setValue(EXISTING_FIELDNAME, VALUE);
        assertEquals("value must be set", VALUE, model.getValue(EXISTING_FIELDNAME));
        assertEquals("valueChangeEvent must be fired for property ", EXISTING_FIELDNAME, valueReport.getLastFieldName());
      }

    /**
     * DataModel which allows empty selection (recordIndex == -1)
     * should start deselected. This is in analogy to RecordSet/RowSet.
     * 
     * As getValue() has no precondition, it must succeed always, returning
     * null if deselected. Some with setValue().
     *
     * related to Issue #86: TabularDataModelAdapter could not cope with rowIndex == -1.
     */

    public void testEmptySelectionOnInit() {
        if (!supportsEmptySelection()) return;
        DataModel adapter = createEmptyDataModel(new MetaData[] { metaData }, 1 );
        assertEquals("recordIndex on start", -1, adapter.getRecordIndex());
        String[] fields = adapter.getFieldNames();
        assertNull("value must be null if empty current", adapter.getValue(fields[0]));
        adapter.setValue(fields[0], VALUE);
    }

    /**
     * Test that model fires valueChangeEvents if values
     * are changed after moving selection.
     *
     */
    public void testFireValueChangeOnIndexChange() {
        DataModel model = createFilledDataModel();
        if (!supportsEmptySelection() || (model.getRecordCount() < 2)) {
            Logger.global.info("valueChangeOnIndexChange not run for " + model);
            return;
        }
        assertFalse("sanity check: we are moving the recordIndex", model.getRecordIndex() == (model.getRecordCount() - 1));
        List oldValues = getValues(model);
        model.addValueChangeListener(valueReport); 
        model.setRecordIndex(model.getRecordCount() - 1);
        int changeCount = assertValueChangeFired(oldValues, model);
        assertTrue("# changed values", changeCount > 0);
    }

    /**
     * test that value change events are fired on deselect.
     * test that all values in deselect state of model are null.
     *
     */
    public void testDeselect() {
        DataModel model = createFilledDataModel();
        if (!supportsEmptySelection() || (model.getRecordCount() < 2)) {
            Logger.global.info("deselect not run for " + model);
            return;
        }
        model.setRecordIndex(model.getRecordCount() - 1);
        List oldValues = getValues(model);
        model.addValueChangeListener(valueReport); 
        model.setRecordIndex(-1);
        int changeCount = assertValueChangeFired(oldValues, model);
        assertTrue("# changed values", changeCount > 0);
        assertNullValues(getValues(model));
    }


    /**
     * Issue #126: AbstractDataModel.getValidators() 
     * was throwing ClassCastException.
     *
     */
    public void testValidatorAccess() {
        DataModel dataModel = createDataModelWithValidator(false);
        dataModel.getValidators();
    }
    
    /**
     * asserts that we got a valueChangeEvent for every changed value.
     * 
     * @param oldValues values before changing recordIndex
     * @param model DataModel that should have fired value change events
     * @return count of change events.
     */
    protected int assertValueChangeFired(List oldValues, DataModel model) {
        String[] fieldNames = model.getFieldNames();
        int changeCount = 0;
        for (int i = 0; i < fieldNames.length; i++) {
            if (!equals(oldValues.get(i), model.getValue(fieldNames[i]))) {
                changeCount++;
                assertTrue("must have fired value change for " + fieldNames[i],
                        valueReport.gotEvent(fieldNames[i]));
            } else {
                assertFalse("must not fire value change for unmodified field" + fieldNames[i],
                        valueReport.gotEvent(fieldNames[i]));
            }
        }
        return changeCount;
        
    }

    /** 
     * convenience: asserts that all values in list are null.
     * 
     * @param values
     */
    protected void assertNullValues(List values) {
        for (Iterator iter = values.iterator(); iter.hasNext();) {
            assertNull("value must be null ",  iter.next());
            
        }
        
    }
    
    protected boolean equals(Object oldValue, Object value) {
        // ARGGGHH - do it once and for all somewhere
        if ((oldValue != null && !oldValue.equals(value)) ||
                (oldValue == null && value != null)) {
            return false;
        } 
        return true;
    }

    /** 
     * returns a list of the current values in model.
     * They are ordered as in getFieldNames().
     *  
     * @param model
     * @return
     */
    protected List getValues(DataModel model) {
        List values = new ArrayList();
        String[] fieldNames = model.getFieldNames();
        for (int i = 0; i < fieldNames.length; i++) {
            values.add(model.getValue(fieldNames[i]));
        }
        return values;
    }
    
    protected abstract boolean supportsEmptySelection();
    protected abstract DataModel createDataModelWithValidator(boolean valid);
    protected abstract DataModel createEmptyDataModel(MetaData[] metaData, int rowCount);
    protected abstract DataModel createFilledDataModel();

 
    protected void setUp() throws Exception {
        super.setUp();
        metaData = new MetaData(EXISTING_FIELDNAME, EXISTING_FIELDNAME.getClass(), EXISTING_FIELDNAME + "Label");
        propertyReport = new PropertyChangeReport();
        valueReport = new ValueChangeReport();
    }

}
