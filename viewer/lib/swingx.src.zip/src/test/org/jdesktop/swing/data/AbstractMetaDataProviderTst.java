/*
 * $Id: AbstractMetaDataProviderTst.java,v 1.1 2004/12/16 17:09:37 kleopatra Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */
package org.jdesktop.swing.data;

import junit.framework.TestCase;

/**
 * Common TestCase which must be passed by  MetaDataProvider 
 * implementations.
 * For each implementation, subclass this and override the
 * abstract methods.
 * 
 * NOTE: the postfix "Tst" is _not_ a spelling error! It's there
 * to hide this from the build (which includes and runs all tests
 * with postfix "Test".
 * 
 * @author Jeanette Winzenburg
 */
public abstract class AbstractMetaDataProviderTst extends TestCase {
    
    protected MetaData[] defaultMetaData;

    public void testEmptyProvider() {
        MetaDataProvider provider = createEmptyMetaDataProvider();
        assertNotNull("provider must not be null", provider);
        assertEquals("fieldCount must be 0", 0, provider.getFieldCount()); 
    }

    public void testFilledProvider() {
        MetaDataProvider provider = createFilledMetaDataProvider();
        assertNotNull("provider must not be null", provider);
        assertEquals("fieldCount must be ", defaultMetaData.length, provider.getFieldCount());
        
        
    }

    /**
     * test that sequence of fieldnames is same as metaData.
     *
     */
    public void testFieldSequence() {
        MetaDataProvider provider = createFilledMetaDataProvider();
        String[] fieldNames = provider.getFieldNames();
        for (int i = 0; i < fieldNames.length; i++) {
            fieldNames[i].equals(defaultMetaData[i].getName());
        }
        
    }
    protected void setUp() throws Exception {
        super.setUp();
        defaultMetaData = createDefaultMetaData();
    }
    
    protected MetaData[] createDefaultMetaData() {
        MetaData[] metas = new MetaData[3];
        metas[0] = new MetaData("firstName", String.class, "First Name");
        metas[1] = new MetaData("second", Boolean.class, "Has Money");
        metas[2] = new MetaData("amount", Number.class, "Total Funds");
        return metas;
    }

    protected void tearDown() throws Exception {
        // TODO Auto-generated method stub
        super.tearDown();
    }
    protected abstract MetaDataProvider createFilledMetaDataProvider();
    
    protected abstract MetaDataProvider createEmptyMetaDataProvider();
}
