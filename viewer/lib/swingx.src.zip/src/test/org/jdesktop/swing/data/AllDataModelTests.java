/*
 * $Id: AllDataModelTests.java,v 1.1 2004/12/17 14:40:34 kleopatra Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */
package org.jdesktop.swing.data;

import junit.framework.Test;
import junit.framework.TestSuite;


/**
 * A collection of test suites for all DataModel tests
 * (convenience for local testing).
 * 
 * @author Jeanette Winzenburg
 */
public class AllDataModelTests {
    public static Test suite() {
        TestSuite suite = new TestSuite("JUnit Tests - MetaDataProviders");
        suite.addTest(new TestSuite(TabularDataModelAdapterTest.class));
        suite.addTest(new TestSuite(DefaultDataModelTest.class));
        return suite;
    }

}
