/*
 * $Id: AllMetaDataProviderTests.java,v 1.1 2004/12/16 17:09:36 kleopatra Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */
package org.jdesktop.swing.data;

import junit.framework.Test;
import junit.framework.TestSuite;


/**
 * A collection of test suites for all MetaDataProvider tests
 * (convenience for local testing).
 * 
 * @author Jeanette Winzenburg
 */
public class AllMetaDataProviderTests {
    public static Test suite() {
        TestSuite suite = new TestSuite("JUnit Tests - MetaDataProviders");
        suite.addTest(new TestSuite(TabularDataModelMetaDataProviderTest.class));
        suite.addTest(new TestSuite(TabularAdapterMetaDataProviderTest.class));
        suite.addTest(new TestSuite(DefaultMetaDataProviderTest.class));
        suite.addTest(new TestSuite(DefaultDataModelMetaDataProviderTest.class));
        return suite;
    }

}
