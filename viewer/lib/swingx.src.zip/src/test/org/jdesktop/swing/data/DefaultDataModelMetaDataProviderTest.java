/*
 * $Id: DefaultDataModelMetaDataProviderTest.java,v 1.1 2004/12/16 17:09:37 kleopatra Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */
package org.jdesktop.swing.data;

/**
 * testing the MetaDataProvider aspect of DefaultDataModel. 
 * 
 * @author Jeanette Winzenburg
 */
public class DefaultDataModelMetaDataProviderTest extends
        AbstractMetaDataProviderTst {

    protected MetaDataProvider createFilledMetaDataProvider() {
        return new DefaultDataModel(defaultMetaData);
    }

    protected MetaDataProvider createEmptyMetaDataProvider() {
        return new DefaultDataModel();
    }

}
