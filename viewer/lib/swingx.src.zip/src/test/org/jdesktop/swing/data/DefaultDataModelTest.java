/*
 * Created on 17.12.2004
 *
 */
package org.jdesktop.swing.data;

/**
 * @author (C) 2004 Jeanette Winzenburg, Berlin
 * @version $Revision: 1.1 $ - $Date: 2004/12/17 14:40:35 $
 */
public class DefaultDataModelTest extends AbstractDataModelTst {

    protected DataModel createDataModelWithValidator(boolean valid) {
        DataModel dataModel = TestDataModelFactory.createDataModelWithValidator(valid);
        return dataModel;
    }

    protected DataModel createEmptyDataModel(MetaData[] metaData, int rowCount) {
        DataModel model = new DefaultDataModel(metaData);
        return model;
    }

    protected boolean supportsEmptySelection() {
        return false;
    }

    protected DataModel createFilledDataModel() {
        return TestDataModelFactory.createFilledPersonModel(true);
    }

}
