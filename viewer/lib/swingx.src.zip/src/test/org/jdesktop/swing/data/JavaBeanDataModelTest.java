/*
 * $Id: JavaBeanDataModelTest.java,v 1.1 2004/08/05 01:29:18 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.swing.data;

import java.awt.Image;

import java.awt.image.BufferedImage;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import junit.framework.TestCase;

public class JavaBeanDataModelTest extends TestCase {

    private JavaBeanDataModel model;
    private TestBean bean, bean2;
    private Date date;
    private Image image;

    protected void setUp() {
	try {
	    model = new JavaBeanDataModel(TestBean.class);
	} catch (Exception ex) {
	    fail(ex.getMessage());
	}
	bean = new TestBean();
	bean.setDate(date = new Date());
	bean.setImage(image = new BufferedImage(100,100,BufferedImage.TYPE_INT_RGB));
    }
    protected void tearDown() {
	model.setJavaBean(null);
	model = null;
	bean = null;
    }

    public void testConstruction() throws Exception {

	DataModel model = new JavaBeanDataModel(TestBean.class);

	List props = new ArrayList();
	props.add("string");
	props.add("integer");
	props.add("float");
	props.add("date");
	props.add("image");
	props.add("array");
	props.add("list");
	props.add("map");

	List fieldNames = Arrays.asList(model.getFieldNames());
	assertTrue("Some missing fields", fieldNames.containsAll(props));
    }

    public void testGetValue() {
	model.setJavaBean(bean);

	// Static comparison
	assertEquals("A String", model.getValue("string"));
	assertEquals(17, ((Integer)model.getValue("integer")).intValue());
	assertEquals(0.17f, ((Float)model.getValue("float")).floatValue(), 0.01f);
	assertEquals(date, model.getValue("date"));
	assertEquals(image, model.getValue("image"));

	// Instance values
	assertEquals(bean.getString(), model.getValue("string"));
	assertEquals(bean.getInteger(), ((Integer)model.getValue("integer")).intValue());
	assertEquals(bean.getFloat(), ((Float)model.getValue("float")).floatValue(), 0.01f);
	assertEquals(bean.getDate(), model.getValue("date"));
	assertEquals(bean.getImage(), model.getValue("image"));
    }

    public void testSetValue() {
	TestBean newBean = new TestBean();
	model.setJavaBean(newBean);

	// Set the values which are the same as an existing bean
	model.setValue("string", bean.getString());
	model.setValue("integer", new Integer(bean.getInteger()));
	model.setValue("float", new Float(bean.getFloat()));
	model.setValue("date", bean.getDate());
	model.setValue("image", bean.getImage());

	assertEquals(newBean.getString(), bean.getString());
	assertEquals(newBean.getInteger(), bean.getInteger());
	assertEquals(newBean.getFloat(), bean.getFloat(), 0.01f);
	assertEquals(newBean.getDate(), bean.getDate());
	assertEquals(newBean.getImage(), bean.getImage());
    }

}
