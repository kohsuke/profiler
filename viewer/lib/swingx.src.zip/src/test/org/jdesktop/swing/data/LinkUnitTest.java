/*
 * $Id: LinkUnitTest.java,v 1.1 2004/08/05 01:29:18 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.swing.data;

import java.net.MalformedURLException;
import java.net.URL;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * A JUnit test case for the Link class
 */
public class LinkUnitTest extends TestCase {

    private static String testText = "This is a foo";
    private static String testTarget = "_blank";
    private static String testTemplate = "http://bugz.sfbay/cgi-bin/showbug?cat=@{1}&subcat=@{2}";
    private static String[] testArgs = { "java", "classes_beans" };
    // 
    private static String testURLStr = "http://bugz.sfbay/cgi-bin/showbug?cat=java&subcat=classes_beans";

    private static URL testURL = null;
    
    public LinkUnitTest() {
	super("com.sun.jdnc.Link unit test");
    }

    protected void setUp() {
	try {
	    testURL = new URL(testURLStr);
	} catch (MalformedURLException ex) {
	    throw new RuntimeException(ex);
	}
    }

    /**
     * A simple test to ensure that values in the 3 arg ctor are preserved
     */
    public void testCtor1() {
	Link link = new Link(testText, testTarget, testURL);

	assertEquals(testText, link.getText());
	assertEquals(testTarget, link.getTarget());
	assertEquals(testURL, link.getURL());
    }

    /**
     * Test the 4 arg ctor which will construct a URL using substitition
     * in the last two args
     */
    public void testCtor2() {
	Link link = new Link(testText, testTarget, testTemplate, testArgs);

	assertEquals(testText, link.getText());
	assertEquals(testTarget, link.getTarget());
	assertEquals(testURL, link.getURL());	
    }    
}
