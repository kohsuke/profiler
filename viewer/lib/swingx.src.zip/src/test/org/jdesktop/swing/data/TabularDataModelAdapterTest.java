/*
 * $Id: TabularDataModelAdapterTest.java,v 1.1 2004/12/17 14:40:34 kleopatra Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */
package org.jdesktop.swing.data;

import java.io.IOException;
import java.net.URL;

import org.jdesktop.swing.util.TestSupport;

/**
 * TabularDataModelAdapter specifics.
 * 
 * @author Jeanette Winzenburg
 */
public class TabularDataModelAdapterTest extends AbstractDataModelTst {
    //  private static final String PREFIX = "resources/";
    private static final String PREFIX = "/org/jdesktop/swing/resources/";

    private static final String STRINGDATA = PREFIX + "stringdata.csv";

    private URL stringDataURL;

    /**
     * test change propagation between adapter and tabularData.
     *
     */
    public void testBidiNotification() {
        TabularDataModel tabularData = TestSupport.loadTabularCSVData(stringDataURL, true);
        TabularDataModelAdapter adapter = new TabularDataModelAdapter(tabularData);
        adapter.setRecordIndex(0);
        adapter.addValueChangeListener(valueReport);
        tabularData.setValueAt("dummy", 0, 0);
        String[] fieldNames = adapter.getFieldNames();
        assertTrue("must have fired", valueReport.gotEvent(fieldNames[0]));
        assertEquals(adapter.getValue(fieldNames[0]), tabularData
                .getValueAt(0, 0));
        valueReport.clear();
        adapter.setValue( fieldNames[0], "othervalue");
        assertTrue("must have fired valueChange", 
                valueReport.gotEvent(fieldNames[0]));
        assertEquals(adapter.getValue(fieldNames[0]), tabularData.getValueAt(0, 0));
        
        
    }

//----------------------- super
    
    protected boolean supportsEmptySelection() {
        return true;
    }

    protected DataModel createDataModelWithValidator(boolean valid) {
        DataModel model = createEmptyDataModel(new MetaData[] { metaData }, 1);
        model.setRecordIndex(0);
        model.addValidator(TestDataModelFactory.createValidator(valid));
        return model;
    }

    protected DataModel createEmptyDataModel(MetaData[] metaData, int rowCount) {
        TabularDataModel tabularData = TestSupport.createTabularDataModel(metaData, rowCount);
        return new TabularDataModelAdapter(tabularData);
    }

    protected DataModel createFilledDataModel() {
        TabularDataModel data = TestSupport.loadTabularCSVData(stringDataURL, true);
        assertEquals("row count", 10, data.getRowCount());
        TabularDataModelAdapter adapter = new TabularDataModelAdapter(data);
        return adapter;
    }

   
    protected void setUp() throws Exception {
        super.setUp();
        System.setProperty(DataLoader.READER_PRIORITY_KEY, String
                .valueOf(Thread.NORM_PRIORITY));
        stringDataURL = getClass().getResource(STRINGDATA);
    }
    protected void tearDown() throws Exception {
        System.getProperties().remove(DataLoader.READER_PRIORITY_KEY);
        super.tearDown();
    }
}
