/*
 * $Id: TabularDataModelMetaDataProviderTest.java,v 1.1 2004/12/16 17:09:37 kleopatra Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */
package org.jdesktop.swing.data;

/**
 * testing the MetaDataProvider aspect of TabularDataModel. 
 * 
 * @author Jeanette Winzenburg
 */
public class TabularDataModelMetaDataProviderTest extends
        AbstractMetaDataProviderTst {

    protected MetaDataProvider createEmptyMetaDataProvider() {
        return new TabularDataModel();
    }

    protected MetaDataProvider createFilledMetaDataProvider() {
        TabularDataModel model = new TabularDataModel(defaultMetaData.length);
        for (int i = 0; i < defaultMetaData.length; i++) {
            model.setColumnMetaData(i, defaultMetaData[i]);
        }
        return model;
    }

}
