/*
 * $Id: TabularDataModelUnitTest.java,v 1.4 2004/09/08 01:37:46 davidson1 Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.swing.data;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import java.io.InputStream;
import java.io.IOException;

import java.net.MalformedURLException;
import java.net.URL;

import java.util.ArrayList;
import java.util.Locale;

import javax.swing.SwingUtilities;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import org.jdesktop.swing.event.ProgressEvent;
import org.jdesktop.swing.event.ProgressListener;


/**
 * JUnit test class for tabular data model.
 *
 * @author Amy Fowler
 */
public class TabularDataModelUnitTest extends TestCase {

    // Ideally test data should be placed in a separate jar
    private static final String PREFIX = "/org/jdesktop/swing/resources/";

    private static final String BUGDATA = PREFIX + "bugdata.txt";
    public static String DATA_URL_STR;

    private static final String STRINGDATA = PREFIX + "stringdata.csv";
    private static final String STRINGDATA2 = PREFIX + "stringdata2.txt";
    public static String STRINGDATA_URL_STR;
    public static String STRINGDATA2_URL_STR;
    public static final String STRINGDATA_COL_NAMES[] = {"firstname",
            "lastname", "street", "city", "state", "zipcode", "phonenumber"};

    public URL dataURL;
    public URL stringDataURL;
    public URL stringData2URL;

    public static void verifyTabularDataModelProperties(TabularDataModel data,
        int columnCount,
        int rowCount,
        URL sourceURL,
        DataLoader loader,
        boolean loading) {

        assertEquals(columnCount, data.getColumnCount());
        assertEquals(rowCount, data.getRowCount());
        assertEquals(sourceURL, data.getSource());
        DataLoader theLoader = data.getLoader();
        if (loader == null) {
            assertEquals(loader, theLoader);
        }
        else {
            assertEquals(loader.getClass(), theLoader.getClass());
        }
        assertEquals(loading, data.isLoading());

    }

    public static void verifyTabularDataTextLoaderProperties(
        TabularDataTextLoader loader,
        String columnDelimiter,
        boolean columnNamesInFirstRow,
        int blockIncrementSize) {
        assertEquals(columnDelimiter, loader.getColumnDelimiter());
        assertEquals(columnNamesInFirstRow, loader.isFirstRowHeader());
        assertEquals(blockIncrementSize, loader.getBlockIncrementSize());
    }


    public void setUp() {

        dataURL = TabularDataModelUnitTest.class.getResource(BUGDATA);
        DATA_URL_STR = dataURL.toExternalForm();

        stringDataURL = TabularDataModelUnitTest.class.getResource(STRINGDATA);
        STRINGDATA_URL_STR = stringDataURL.toExternalForm();

        stringData2URL = TabularDataModelUnitTest.class.getResource(STRINGDATA2);
        STRINGDATA2_URL_STR = stringData2URL.toExternalForm();

        // get the event dispatch thread spinning, else the data load can hang
        SwingUtilities.invokeLater(new Runnable() {
                public void run() {
                    ;
                }
            });
    }

    public void testTabularDataModelConstructors() {
        TabularDataModel data = null;

        data = new TabularDataModel();
        verifyTabularDataModelProperties(data, 0, 0, null,
                                         new TabularDataTextLoader(),
                                         false);

        data = new TabularDataModel(5);
        verifyTabularDataModelProperties(data, 5, 0, null,
                                         new TabularDataTextLoader(),
                                         false);

        try {
            data = new TabularDataModel(DATA_URL_STR);
            verifyTabularDataModelProperties(data, 8, 0, dataURL,
                                         new TabularDataTextLoader(),
                                         false);
        }
        catch (MalformedURLException e) {
            fail("testConstructors MalFormedURLException: url="+DATA_URL_STR);
        }

        try {
            data = new TabularDataModel(DATA_URL_STR, 8);
            verifyTabularDataModelProperties(data, 8, 0, dataURL,
                                 new TabularDataTextLoader(),
                                 false);
        }
        catch (MalformedURLException e) {
            fail("testConstructors MalFormedURLException: url="+DATA_URL_STR);
        }

    }

    public void testTabularDataModelProperties() {
        TabularDataModel data = new TabularDataModel();
        data.setColumnCount(10);
        data.setSource(dataURL);
        DataLoader dummyLoader = new DummyDataLoader();
        data.setLoader(dummyLoader);

        verifyTabularDataModelProperties(data, 10, 0, dataURL,
                                         dummyLoader, false);

        try {
            data.setColumnCount( -2);
            fail("should not allow setting columnCount to negative number");
        } catch (IllegalArgumentException e) {
            // success
        }
    }

    public void testTabularDataModelColumnMetaData() {
        int columnCount = 3;
        TabularDataModel data = new TabularDataModel(columnCount);

        for (int i = 0; i < columnCount; i ++) {
            MetaData metaData = data.getColumnMetaData(i);
            assertNotNull(metaData);
            assertEquals(String.class, metaData.getElementClass());
            assertEquals("column"+i, metaData.getName());
            assertEquals(String.class, data.getColumnClass(i));
            assertEquals("column"+i, data.getColumnName(i)); // by default label == name

            MetaData newMetaData = new MetaData("field"+i, Integer.class);
            data.setColumnMetaData(i, newMetaData);
            metaData = data.getColumnMetaData(i);
            assertEquals(newMetaData, metaData);
            assertEquals(Integer.class, data.getColumnClass(i));
            assertEquals("field"+i, data.getColumnName(i)); // by default label == name
        }
    }

    public void testTabularDataModelLoading() {
        TabularDataModel data = null;
        try {
            data = new TabularDataModel(DATA_URL_STR);

            // verify the tabular data model is generating proper insert events
            final TableModelEventTracker tracker = new TableModelEventTracker(1) {
                private int rowCount = 0;
                public void tableChanged(TableModelEvent e) {
                    if (e.getType() == TableModelEvent.INSERT) {
                        rowCount += (e.getLastRow() - e.getFirstRow());
                        if (rowCount == 1275) {
                            gotEvent[0] = true;
                        }
                    }
                }
            };
            data.addTableModelListener(tracker);

            PropertyChangeListener pcl = new PropertyChangeListener() {
                private boolean doingLoad = false;
                public void propertyChange(PropertyChangeEvent e) {
                    TabularDataModel data = (TabularDataModel)e.getSource();
                    if (e.getPropertyName().equals("loading")) {
                        boolean loading = ((Boolean)e.getNewValue()).booleanValue();
                        if (!doingLoad && loading) {
                            doingLoad = true;
                        }
                        if (doingLoad && !loading) {
                            // we're done loading now, check rowcount
                int count = data.getColumnCount();
                            assertEquals("ERROR: columnCount should be 8 != " + count,
                     8, count);
                count = data.getRowCount();
                            assertEquals("ERROR: rowCount should be 1275 == " + count,
                     1275, count);
                            assertTrue(tracker.gotEvent[0]);
                            data.removePropertyChangeListener(this);
                        }
                    }
                }
            };
            data.addPropertyChangeListener(pcl);

            data.startLoading();
        }
        catch (Exception e) {
            fail("testTabularDataModelLoading: exception: msg="+e.getMessage());
        }

        // Now test firstRowHeader property on loader
        try {
            data = new TabularDataModel(stringDataURL);
            TabularDataTextLoader loader = (TabularDataTextLoader) data.
                getLoader();
            loader.setColumnDelimiter(",");
            loader.setFirstRowHeader(true);
        } catch (Exception e) {
            fail("testTabularDataModelLoading: "+STRINGDATA_URL_STR+" "+e.getMessage());
        }
        assertEquals(7, data.getColumnCount());
        assertEquals("firstname", data.getColumnName(0));
        assertEquals("lastname", data.getColumnName(1));
        assertEquals("street", data.getColumnName(2));
        assertEquals("city", data.getColumnName(3));
        assertEquals("state", data.getColumnName(4));
        assertEquals("zipcode", data.getColumnName(5));
        assertEquals("phonenumber", data.getColumnName(6));

        try {
            data.startLoading();
        } catch (Exception e) {
            fail("testTabularDataModelLoading: "+STRINGDATA_URL_STR+" "+e.getMessage());
        }

        while(data.isLoading());

        assertEquals(10, data.getRowCount());
    }

    public void testTabularDataModelInsert() {
        final int listRowCount = 3;
        TabularDataModel data = new TabularDataModel(3);
        Object row[] = {"John", "Doe", new Integer(25)};
        Object dataRow[] = null;
        ArrayList rowList = new ArrayList();
        for(int i = 0; i < listRowCount; i++) {
            rowList.add(row);
        }

        // verify the tabular data model is generating proper insert events
        TableModelEventTracker tracker = new TableModelEventTracker(4) {
            public void tableChanged(TableModelEvent e) {
                if (e.getType() == TableModelEvent.INSERT) {
                    if (e.getFirstRow() == 0 && e.getLastRow() == 0) {
                        gotEvent[0] = true;
                    }
                    if (e.getFirstRow() == 1 && e.getLastRow() == listRowCount) {
                        gotEvent[1] = true;
                    }
                    if (e.getFirstRow() == 3 && e.getLastRow() == 3) {
                        gotEvent[2] = true;
                    }
                    if (e.getFirstRow() == 2 && e.getLastRow() == listRowCount+1) {
                        gotEvent[3] = true;
                    }
                }
            }
        };
        data.addTableModelListener(tracker);

        // test 0
        data.addRow(row);
        assertEquals(1, data.getRowCount());
        dataRow = data.getRow(0);
        assertEquals(row, dataRow);
        // verify copy
        assertNotSame(row, dataRow);
        assertTrue(tracker.gotEvent[0]);

        // test 1
        row[0] = "Jane";
        data.addRows(rowList);
        assertEquals(1+listRowCount, data.getRowCount());
        for(int i = 1; i < listRowCount+1; i++) {
            dataRow = data.getRow(i);
            assertEquals(row, dataRow);
            // verify copy
            assertNotSame(row, dataRow);
        }
        assertTrue(tracker.gotEvent[1]);

        // test 2
        row[1] = "Smith";
        data.insertRow(3, row);
        assertEquals(2+listRowCount, data.getRowCount());
        dataRow = data.getRow(3);
        assertEquals(row, dataRow);
        // verify copy
        assertNotSame(row, dataRow);
        assertTrue(tracker.gotEvent[2]);

        // test 3
        row[0] = "Jim";
        data.insertRows(2, rowList);
        assertEquals(2+(2*listRowCount), data.getRowCount());
        for(int i = 2; i < listRowCount+2; i++) {
            dataRow = data.getRow(i);
            assertEquals(row, dataRow);
            // verify copy
            assertNotSame(row, dataRow);
        }
        assertTrue(tracker.gotEvent[3]);
    }

    public void testTabularDataModelDelete() {

        Object dataRow[] = null;
        int rowCount = 10;
        TabularDataModel data = initializeSimpleTabularDataModel(rowCount);

        // verify the tabular data model is generating proper delete events
         TableModelEventTracker tracker = new TableModelEventTracker(2) {
             public void tableChanged(TableModelEvent e) {
                 if (e.getType() == TableModelEvent.DELETE) {
                     if (e.getFirstRow() == 0 && e.getLastRow() == 0) {
                         gotEvent[0] = true;
                     }
                     if (e.getFirstRow() == 0 && e.getLastRow() == 3) {
                         gotEvent[1] = true;
                     }
                 }
             }
         };
         data.addTableModelListener(tracker);

        // test 0: delete first row
        data.deleteRow(0);
        assertEquals(rowCount-1, data.getRowCount());
        // ensure correct one was deleted
        dataRow = data.getRow(0);
        assertEquals("value1", dataRow[0]);
        assertEquals(new Integer(1), dataRow[1]);
        assertTrue(tracker.gotEvent[0]);

        // test 1: delete range of rows
        data.deleteRows(0,3);
        assertEquals(rowCount-5, data.getRowCount());
        assertTrue(tracker.gotEvent[1]);

        // test 2: delete last row
        data.deleteRow(data.getRowCount()-1);
        assertEquals(rowCount-6, data.getRowCount());

    }

    public void testTabularDataModelGetValue() {
        int rowCount = 10;
        TabularDataModel data = initializeSimpleTabularDataModel(rowCount);

        assertEquals("value1", (String)data.getValueAt(1, 0));
        assertEquals(new Integer(0), (Integer)data.getValueAt(0, 1));
        assertEquals(Boolean.TRUE, (Boolean)data.getValueAt(3, 2));
        assertEquals(new Float(5*3.3), (Float)data.getValueAt(5, 3));
        assertEquals(new Long(9+5555), (Long)data.getValueAt(9, 4));

    }

    public void testTabularDataModelSetValue() {
        int rowCount = 10;
        TabularDataModel data = initializeSimpleTabularDataModel(rowCount);

        // verify the tabular data model is generating proper change events
        TableModelEventTracker tracker = new TableModelEventTracker(2) {
            public void tableChanged(TableModelEvent e) {
                if (e.getType() == TableModelEvent.UPDATE) {
                    if (e.getFirstRow() == 0 && e.getLastRow() == 0 &&
                        e.getColumn() == 0) {
                        gotEvent[0] = true;
                    }
                    if (e.getFirstRow() == 5 && e.getLastRow() == 5 &&
                        e.getColumn() == 2) {
                        gotEvent[1] = true;
                    }
                }
            }
        };
        data.addTableModelListener(tracker);

        // test 0
        data.setValueAt("string0", 0, 0);
        assertEquals("string0", (String)data.getValueAt(0,0));
        assertTrue(tracker.gotEvent[0]);

        // test 1
        data.setValueAt(Boolean.FALSE, 5, 2);
        assertEquals(Boolean.FALSE, (Boolean)data.getValueAt(5,2));
        assertTrue(tracker.gotEvent[1]);
    }

    public void testTabularDataModelgetColumnIndex() {
        int rowCount = 5;
        TabularDataModel data = initializeSimpleTabularDataModel(rowCount);

        assertEquals(0, data.getColumnIndex("stringcolumn"));
        assertEquals(4, data.getColumnIndex("longcolumn"));

        try {
            data.getColumnIndex("whichcolumn");
            fail("getColumnIndex should throw IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // success
        }
    }

    public void testTabularDataModelgetColumnName() {
        int rowCount = 5;
        TabularDataModel data = initializeSimpleTabularDataModel(rowCount);

        // note that getColumnName actually returns the *label*, not the name/id
        assertEquals("Strings", data.getColumnName(0));
        assertEquals("Integers", data.getColumnName(1));
        assertEquals("Booleans", data.getColumnName(2));
        assertEquals("Floats", data.getColumnName(3));
        assertEquals("Longs", data.getColumnName(4));
    }


    public void testTabularDataTextLoaderConstructors() {
        TabularDataTextLoader loader = new TabularDataTextLoader();
        verifyTabularDataTextLoaderProperties(loader, "\t", false, 50);

        loader = new TabularDataTextLoader("foo", true, 100);
        verifyTabularDataTextLoaderProperties(loader, "foo", true, 100);
    }

    public void testTabularDataTextLoaderProperties() {
        TabularDataTextLoader loader = new TabularDataTextLoader();
        loader.setBlockIncrementSize(25);
        loader.setColumnDelimiter("bar");
        loader.setFirstRowHeader(true);
        verifyTabularDataTextLoaderProperties(loader, "bar", true, 25);
    }

    public void testTabularDataTextLoaderInitializeMetaData() {
        TabularDataModel data = new TabularDataModel();
        TabularDataTextLoader loader = new TabularDataTextLoader(",", true,
            100);
        try {
            final InputStream is = stringDataURL.openStream();
            loader.loadMetaData(data, is);

            int columnCount = data.getColumnCount();
            assertEquals(7, columnCount);
            for (int i = 0; i < columnCount; i++) {
                MetaData metaData = data.getColumnMetaData(i);
                assertEquals(STRINGDATA_COL_NAMES[i], metaData.getName());
            }
        } catch (Exception e) {
            fail("testTabularDataTextLoaderInitializeMetaData exception: msg="+e.getMessage());
        }
    }

    public void testTabularDataTextLoaderStartLoading() {
        TabularDataModel data = new TabularDataModel();
        TabularDataTextLoader loader = new TabularDataTextLoader(",", true, 3);
        try {
            InputStream is = stringDataURL.openStream();
            ProgressTracker progressTracker = new ProgressTracker();
            loader.addProgressListener(progressTracker);
            loader.loadMetaData(data, is);
            is.close();

            is = stringDataURL.openStream();
            loader.startLoading(data, is);

            while(!progressTracker.done && progressTracker.error == null);

            assertTrue(progressTracker.done);
            assertEquals(10, data.getRowCount());
            assertEquals("Gibson", (String)data.getValueAt(7,1));
        } catch (Exception e) {
            fail("testTabularDataTextLoaderStartLoading exception: msg="+e.getMessage());
        }

        data = new TabularDataModel();
        loader = new TabularDataTextLoader("boo", false, 10);
        try {
            InputStream is = stringData2URL.openStream();
            ProgressTracker progressTracker = new ProgressTracker();
            loader.addProgressListener(progressTracker);
            loader.loadMetaData(data, is);
            is.close();

            is = stringData2URL.openStream();
            loader.startLoading(data, is);

            while (!progressTracker.done && progressTracker.error == null);

            assertTrue(progressTracker.done);
            assertEquals(30, data.getRowCount());
            assertEquals("two", (String) data.getValueAt(0, 1));
            assertEquals("5", (String)data.getValueAt(1,4));
            assertEquals("first", (String)data.getValueAt(5, 0));
            assertEquals("six", (String)data.getValueAt(9,5));
        }
        catch (Exception e) {
            fail("testTabularDataTextLoaderStartLoading exception: msg=" +
                 e.getMessage());
        }
    }


    public void assertEquals(Object[] expected, Object[] actual) {
        assertEquals(expected.length, actual.length);
        for(int i = 0; i < expected.length; i++) {
            assertEquals(expected[i], actual[i]);
        }
    }

    protected TabularDataModel initializeSimpleTabularDataModel(int rowCount) {
        int columnCount = 5;
        TabularDataModel data = new TabularDataModel(columnCount);
        data.getColumnMetaData(0).setName("stringcolumn");
        data.getColumnMetaData(0).setLabel("Strings");
        data.getColumnMetaData(1).setName("intcolumn");
        data.getColumnMetaData(1).setLabel("Integers");
        data.getColumnMetaData(2).setName("booleancolumn");
        data.getColumnMetaData(2).setLabel("Booleans");
        data.getColumnMetaData(3).setName("floatcolumn");
        data.getColumnMetaData(3).setLabel("Floats");
        data.getColumnMetaData(4).setName("longcolumn");
        data.getColumnMetaData(4).setLabel("Longs");

        data.getColumnMetaData(1).setElementClass(Integer.class);
        data.getColumnMetaData(2).setElementClass(Boolean.class);
        data.getColumnMetaData(3).setElementClass(Float.class);
        data.getColumnMetaData(4).setElementClass(Long.class);

        for (int i = 0; i < rowCount; i++) {
            Object row[] = new Object[columnCount];
            row[0] = "value" + i;
            row[1] = new Integer(i);
            row[2] = Boolean.TRUE;
            row[3] = new Float(i*3.3);
            row[4] = new Long(i+5555);
            data.addRow(row);
        }
        return data;
    }

    private class DummyDataLoader extends DataLoader {
        public void loadMetaData(Object model, InputStream is) {

        }
        public void readData(InputStream is) throws IOException,
            ConversionException {
        }
        public void loadData(Object model) {
        }

    }

    private abstract class TableModelEventTracker implements TableModelListener {
        public boolean gotEvent[];
        public TableModelEventTracker(int testCount) {
            gotEvent = new boolean[testCount];
            for(int i = 0; i < gotEvent.length; i++) {
                gotEvent[i] = false;
            }
        }
        public abstract void tableChanged(TableModelEvent e);
    }

/*
    private class ProgressTracker implements ProgressListener {
        public boolean done;
        public Throwable error;
        public ProgressTracker() {
            done = false;
            error = null;
        }
        public void inProgress(ProgressEvent event) {
            if (event.isComplete()) {
                done = true;
            }
        }
        public void errorOccurred(ProgressEvent event) {
            error = event.getError();
        }
    }
 */
    private class ProgressTracker implements ProgressListener {
        public boolean done;
        public Throwable error;
        public ProgressTracker() {
            done = false;
            error = null;
        }
        public void progressStarted(ProgressEvent e) {

        }
        public void progressIncremented(ProgressEvent e) {

        }
        public void progressEnded(ProgressEvent evt) {
            done = true;
        }
        public void exception(ProgressEvent evt) {
            error = evt.getThrowable();
        }
    }

    public static void main(String args[]) {
        TabularDataModelUnitTest test = new TabularDataModelUnitTest();
        test.setUp();

        // TabularDataModel tests
        test.testTabularDataModelColumnMetaData();
        test.testTabularDataModelConstructors();
        test.testTabularDataModelDelete();
        test.testTabularDataModelgetColumnIndex();
        test.testTabularDataModelgetColumnName();
        test.testTabularDataModelGetValue();
        test.testTabularDataModelInsert();
        test.testTabularDataModelLoading();
        test.testTabularDataModelProperties();
        test.testTabularDataModelSetValue();

        // TabularDataTextLoader tests

        test.testTabularDataTextLoaderConstructors();
        test.testTabularDataTextLoaderInitializeMetaData();
        test.testTabularDataTextLoaderProperties();
        test.testTabularDataTextLoaderStartLoading();
    }

}
