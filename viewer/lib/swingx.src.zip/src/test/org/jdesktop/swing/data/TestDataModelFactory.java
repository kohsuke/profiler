/*
 * $Id: TestDataModelFactory.java,v 1.2 2004/12/17 14:40:34 kleopatra Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */
package org.jdesktop.swing.data;

import java.util.Locale;

/**
 * static factory creating DataModels for test cases.
 * 
 * @author Jeanette Winzenburg
 */
public class TestDataModelFactory {

    public static String statusTypes[] = {
        "new", "existing", "cancelled"
    };
    public static String states[] = {
    "Alabama", "Alaska", "Arizona", "Arkansas",
    "California", "Colorado", "Connecticut",
    "Delaware", "Florida", "Georgia", "Hawaii",
    "Idaho", "Illinois", "Indiana", "Iowa",
    "Kansas", "Kentucky", "Louisiana",
    "Maine", "Mariland", "Massachusetts", "Michegan",
    "Minnesota", "Mississippi", "Missouri", "Montana",
    "Nebraska", "Nevada", "New Hampshire", "New Jersey",
    "New Mexico", "New York", "North Carolina", "North Dakota",
    "Ohio", "Oklahoma", "Oregan", "Pennsylvania",
    "Rhode Island", "South Carolina", "South Dakota",
    "Tennessee", "Texas", "Utah", "Vermont", "Virgina",
    "Washington", "West Virginia", "Wisconsin", "Wyoming" };

    /** 
     * returns a one-field dataModel with a Validator.
     * 
     * @param valid the immutable return value of the Validator.
     * @return
     */
    public static DataModel createDataModelWithValidator(boolean valid) {
        DefaultDataModel model = new DefaultDataModel();
        model.addField(new MetaData("simpleton"));
        model.addValidator(createValidator(valid));
        return model;
    }

    /** 
     * returns a Validator with a fixed validation restult.
     *  
     * @param valid the fixed validation result.
     * @return
     */
    public static Validator createValidator(final boolean valid) {
        
        Validator v = new Validator() {

            public boolean validate(Object value, Locale locale, String[] error) {
                return valid;
            }
            
        };
        return v;
    }

    public static DefaultDataModel createPersonModel() {
        DefaultDataModel personModel = new DefaultDataModel();
    
        StringMetaData stringMetaData = new StringMetaData("firstname", "First Name");
        stringMetaData.setMinValueCount(1); // required
        stringMetaData.setDisplayWidth(14);
        stringMetaData.setMinLength(1);
        stringMetaData.setMaxLength(24);
        personModel.addField(stringMetaData);
    
        stringMetaData = new StringMetaData("middleinitial", "Middle Initial");
        stringMetaData.setDisplayWidth(2);
        stringMetaData.setMinLength(1);
        stringMetaData.setMaxLength(2);
        personModel.addField(stringMetaData);
    
        stringMetaData = new StringMetaData("lastname", "Last Name");
        stringMetaData.setMinValueCount(1); // required
        stringMetaData.setDisplayWidth(14);
        stringMetaData.setMinLength(1);
        stringMetaData.setMaxLength(24);
        personModel.addField(stringMetaData);
    
        NumberMetaData numberMetaData = new NumberMetaData("age", Integer.class,
            "Age");
        numberMetaData.setMinimum(new Integer(0));
        numberMetaData.setMaximum(new Integer(110));
        personModel.addField(numberMetaData);
    
        MetaData metaData = new MetaData("married", Boolean.class, "Married");
        personModel.addField(metaData);
    
        numberMetaData = new NumberMetaData("customerid", Integer.class, "Customer ID");
        numberMetaData.setReadOnly(true);
        personModel.addField(numberMetaData, new Integer(112));
    
        EnumeratedMetaData enumMetaData = new EnumeratedMetaData("status", String.class, "Status");
        enumMetaData.setEnumeration(statusTypes);
        personModel.addField(enumMetaData, "new");
    
        stringMetaData = new StringMetaData("comments", "Comments");
        stringMetaData.setMaxLength(100);
        stringMetaData.setMultiLine(true);
        personModel.addField(stringMetaData);
    
        return personModel;
    
    }

    public static DataModel createFilledPersonModel(boolean valid) {
        DataModel model = createPersonModel();
        model.setValue("firstname", "Melissa");
        model.setValue("lastname", "Etheridge");
        if (valid) {
            model.setValue("age", new Integer(46));
        } else {
            model.setValue("age", new Integer(-2));
        }
        model.setValue("married", Boolean.TRUE);
        return model;
    }

    public static DefaultDataModel createAddressModel() {
        DefaultDataModel addressModel = new DefaultDataModel();
    
        StringMetaData metaData = new StringMetaData("street", "Street");
        metaData.setMinValueCount(1);
        metaData.setDisplayWidth(18);
        metaData.setMaxLength(32);
        addressModel.addField(metaData);
    
        metaData = new StringMetaData("city", "City");
        metaData.setMinValueCount(1);
        metaData.setDisplayWidth(16);
        metaData.setMaxLength(24);
        addressModel.addField(metaData);
    
        EnumeratedMetaData enumMetaData =
            new EnumeratedMetaData("state", String.class, "State");
        enumMetaData.setEnumeration(states);
        enumMetaData.setMinValueCount(1);
        addressModel.addField(enumMetaData);
    
        metaData =
            new StringMetaData("zipcode", "Zipcode");
        metaData.setMinLength(5);
        metaData.setMaxLength(9);
        metaData.setMinValueCount(1);
        addressModel.addField(metaData);
    
        return addressModel;
    }

    public static DefaultDataModel createNestedPersonModel() {
        DefaultDataModel personModel = createPersonModel();
        MetaData metaData = new MetaData("address", DataModel.class, "Address");
        personModel.addField(metaData, createAddressModel());
        return personModel;
    }


}
