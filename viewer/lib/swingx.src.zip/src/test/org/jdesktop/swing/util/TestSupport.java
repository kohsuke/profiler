/*
 * $Id: TestSupport.java,v 1.2 2004/12/17 14:40:37 kleopatra Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */
package org.jdesktop.swing.util;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import java.io.IOException;
import java.net.URL;
import java.util.HashMap;

import org.jdesktop.swing.data.MetaData;
import org.jdesktop.swing.data.TabularDataModel;
import org.jdesktop.swing.data.TabularDataTextLoader;

/**
 * Contains utilities to assist with automated and interactive API tests.
 * @author Amy Fowler
 * @version 1.0
 */
public class TestSupport {

    public static TabularDataModel createTabularDataModel(MetaData[] metaData, int rowCount) {
        TabularDataModel tabularData = new TabularDataModel(metaData.length);
        for (int i = 0; i < metaData.length; i++) {
            tabularData.setColumnMetaData(i, metaData[i]);
        }
        for (int i = 0; i < rowCount; i++) {
            tabularData.addRow(new Object[metaData.length]);
            
        }
        return tabularData;
      }

    
    public static TabularDataModel loadTabularCSVData(URL dataURL, boolean firstRowHeader) {
        TabularDataModel data = new TabularDataModel(dataURL);
        data.getColumnCount();
        TabularDataTextLoader loader = (TabularDataTextLoader) data.getLoader();
        loader.setColumnDelimiter(",");
        loader.setFirstRowHeader(firstRowHeader);
        try {
            data.startLoading();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        int row = 0;
        while (data.isLoading()) {
            //      System.out.println(row++);
        }
        return data;
    }

    /**
     * Class which can be used to track property change events.
     * @author not attributable
     * @version 1.0
     */
    public static class PropertyChangeTracker implements PropertyChangeListener {
        private HashMap changedProperties = new HashMap();

        public void propertyChange(PropertyChangeEvent e) {
            changedProperties.put(e.getPropertyName(), e);
        }

        /**
         *
         * @param propertyName String containing the name of the property
         * @return boolean indicating whether or not a property change event
         *         was fired for the property
         */
        public boolean gotPropertyChangeEvent(String propertyName) {
            return changedProperties.containsKey(propertyName);
        }

        /**
         * @throws NullPointerException if property change event did not occur
         * @param propertyName String containing the name of the property
         * @return Object containing the new value of the property
         */
        public Object getNewPropertyValue(String propertyName) {
            PropertyChangeEvent e = (PropertyChangeEvent)
                                          changedProperties.get(propertyName);
            return e.getNewValue();
        }

        /**
         * @throws NullPointerException if property change event did not occur
         * @param propertyName String containing the name of the property
         * @return Object containing the old value of the property
         */
        public Object getOldPropertyValue(String propertyName) {
            PropertyChangeEvent e = (PropertyChangeEvent)
                                          changedProperties.get(propertyName);
            return e.getOldValue();
        }

        public boolean hasPropertyChangeEvents() {
            return !changedProperties.isEmpty();
        }

        /**
         * Clears any recorded property change events from tracker.
         */
        public void clear() {
            changedProperties.clear();
        }
    }
}