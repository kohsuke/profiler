/*
 * $Id: ValueChangeReport.java,v 1.1 2004/11/29 16:12:22 kleopatra Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.swing.util;

import java.util.*;

import org.jdesktop.swing.data.ValueChangeEvent;
import org.jdesktop.swing.data.ValueChangeListener;

/**
 * A ValueChangeListener that stores the received ValueChangeEvents.
 */
public class ValueChangeReport implements ValueChangeListener {

    /**
     * Holds a list of all received ValueChangeEvents.
     */
    private List events = new LinkedList();

    //---------------------- implement ValueChangeListener

    public void valueChanged(ValueChangeEvent evt) {
        events.add(0, evt);
    }

    public int getEventCount() {
        return events.size();
    }

    public boolean hasEvents() {
        return !events.isEmpty();
    }

    public ValueChangeEvent getLastEvent() {
        return events.isEmpty() ? null : (ValueChangeEvent) events.get(0);
    }

    public String getLastFieldName() {
        return getLastEvent().getFieldName();
    }

    public boolean gotEvent(Object fieldName) {
        for (Iterator iter = events.iterator(); iter.hasNext();) {
            ValueChangeEvent event = (ValueChangeEvent) iter.next();
            if (fieldName.equals(event.getFieldName()))
                return true;
        }
        return false;
    }

    public void clear() {
        events.clear();
    }
}