package com.thoughtworks.xstream.converters;

public interface MarshallingContext {

    void convertAnother(Object nextItem);

}
