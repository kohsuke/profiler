package com.thoughtworks.acceptance.someobjects;

import java.util.List;

/**
 *
 * 
 * @author <a href="mailto:jason@maven.org">Jason van Zyl</a>
 *
 * @version $Id: HandlerManager.java,v 1.1 2004/03/07 10:26:50 joe Exp $
 */
public class HandlerManager
{
    List handlers;

    public List getHandlers()
    {
        return handlers;
    }
}
