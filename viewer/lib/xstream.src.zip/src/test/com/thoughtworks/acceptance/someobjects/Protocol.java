package com.thoughtworks.acceptance.someobjects;

/**
 *
 * 
 * @author <a href="mailto:jason@maven.org">Jason van Zyl</a>
 *
 * @version $Id: Protocol.java,v 1.1 2004/03/07 10:26:50 joe Exp $
 */
public class Protocol
{
    private String id;

    public String getId()
    {
        return id;
    }
}
