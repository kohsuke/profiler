package com.thoughtworks.acceptance.someobjects;

import com.thoughtworks.acceptance.StandardObject;

import java.util.ArrayList;
import java.util.List;

public class WithList extends StandardObject {

    public List things = new ArrayList();

}
