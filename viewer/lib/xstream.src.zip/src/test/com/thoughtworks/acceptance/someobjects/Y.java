package com.thoughtworks.acceptance.someobjects;

import com.thoughtworks.acceptance.StandardObject;

public class Y extends StandardObject {
    public String yField;
}
